<div class="row">
	<div class="col-md-12 col-sm-12">
		<div class="box">
			<div class="box-header">
				<h2 class="box-title">Data Konfirmasi Pembayaran</h2>
			</div>
			<div class="box-body">
				<table id="tableku" class="table table-hover">
					<thead>
						<tr>
							<th>No</th>
							<th>Nama</th>
							<th>Posisi</th>
							<th>Alamat</th>
							<th>Aksi</th>
						</tr>
					</thead>
					<tbody>
					<?php  foreach ($dt_mem as $key => $data) { ?>
						<tr>
							<td><?php echo $key+1; ?></td>
							<td><?php echo $data['nama_lengkap']; ?></td>
							<td><?php echo $data['nama_posisi']; ?></td>
							<td><?php echo $data['alamat']; ?></td>
							<td>
								<a href="<?php echo base_url('admin/konfirmasipembayaran'); ?>/<?php echo $data['id_member']; ?>/<?php echo $data['id_pembayaran_pendaftaran']; ?>" class="btn btn-success btn-xs"><i class="fa fa-check"></i> Konfirmasi</a>
							</td>
						</tr>
					<?php } ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
