<div class="row">
	<div class="col-md-12">
		<div class="box">
			<div class="box-header">
				<h2 class="box-title">Konfirmasi Pembayaran</h2>
			</div>
			<div class="box-body">
				<form method="POST" action="<?php echo base_url('prosesadmin/konfirmasipembayaran'); ?>/<?php echo $idmem; ?>/<?php echo $idpem; ?>">
					<div class="form-group">
						<label>Nama</label>
						<input type="text" id="nama" class="form-control" name="nama" readonly="true" value="<?php echo $dt_mem['nama_lengkap']; ?>" />
					</div>
					<div class="form-group">
						<label>Nominal Tagihan</label>
						<input type="number" id="tagihan" class="form-control" name="tagihan" readonly="true" value="<?php echo $dt_pem['nominal_tagihan']; ?>" />
					</div>
					<div class="form-group">
						<label>Nama A/N</label>
						<input type="text" name="nama" id="nama" class="form-control" />
					</div>
					<div class="form-group">
						<label>No HP</label>
						<input type="number" name="no_hp" id="no_hp" class="form-control" />
						<p class="text-danger">No HP yang dapat dihubungi, untuk pemberitahuan akun.</p>
					</div>
					<div class="form-group">
						<label>Nama Bank</label>
						<input type="text" name="nama_bank" id="nama_bank" class="form-control" />
					</div>
					<div class="form-group">
						<label>Nominal Bayar</label>
						<input type="number" name="nominal_bayar" id="nominal_bayar" class="form-control" />
					</div>
			</div>
			<div class="box-footer">
				<button type="submit" id="formbtn" class="btn btn-success"><i class="fa fa-save"></i> Simpan</button>
				<a href="<?php echo base_url('admin/konfirmasipembayaranview'); ?>/<?php echo $idmem; ?>/<?php echo $idpem; ?>" class="btn btn-warning">Cancel</a>
			</div>
				</form>
		</div>
	</div>
</div>
<script>
	function validateText(id){
		if ($('#'+id).val()== null || $('#'+id).val()== "") {
			var div = $('#'+id).closest('div');
			div.addClass("has-error has-feedback");
			return false;
		}
		else{
			var div = $('#'+id).closest('div');
			div.removeClass("has-error has-feedback");
			return true;	
		}
	}
	$(document).ready(function(){
		$("#formbtn").click(function(){
			var tagihan = parseInt($('#tagihan').val());
			var bayar = parseInt($('#nominal_bayar').val());
			if (!validateText('nama')) {
				$('#nama').focus();
				return false;
			}
			else if (!validateText('no_hp')) {
				$('#no_hp').focus();
				return false;
			}
			else if (!validateText('nama_bank')) {
				$('#nama_bank').focus();
				return false;
			}
			else if (!validateText('nominal_bayar')) {
				$('#nominal_bayar').focus();
				return false;
			}
			else if (bayar < tagihan) {
				alert("Nominal Bayar Tidak Cukup");
				return false;
			}
			return true;
		});
	});
</script>