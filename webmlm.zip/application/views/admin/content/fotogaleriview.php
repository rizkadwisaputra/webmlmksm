<div class="row">
	<div class="col-md-12 col-sm-12">
		<div class="box">
			<div class="box-header">
				<h2 class="box-title">Foto Galeri View</h2>
			</div>
			<div class="box-body">
				<table id="tableku" class="table table-hover">
					<thead>
						<tr>
							<th>No</th>
							<th>Judul</th>
							<th>Foto</th>
							<th>Aksi</th>
						</tr>
					</thead>
					<tbody>
					<?php  foreach ($dt as $key => $data) { ?>
						<tr>
							<td><?php echo $key+1; ?></td>
							<td><?php echo $data['judul_foto']; ?></td>
							<td>
								<img src="<?php echo base_url("assets/foto-galeri"); ?>/<?php echo $data['foto']; ?>" class="img-responsive" width="150">
							</td>
							<td>
								<a href="<?php echo base_url('prosesadmin/fotogaleridelete'); ?>/<?php echo $data['id_foto_galeri']; ?>" class="btn btn-danger btn-xs" onclick="return confirm('Lanjutkan Hapus?');"><i class="fa fa-trash"></i> Delete</a>
							</td>
						</tr>
					<?php } ?>
					</tbody>
				</table>
			</div>
			<div class="box-footer">
				<a href="<?php echo base_url("admin/fotogaleriadd"); ?>" class="btn btn-info"><i class="fa fa-plus"></i> Tambah Foto</a>
			</div>
		</div>
	</div>
</div>
