<div class="row">
	<div class="col-md-12 col-sm-12">
		<div class="box">
			<div class="box-header">
				<h2 class="box-title">Presentasi View</h2>
			</div>
			<div class="box-body">
				<table id="tableku" class="table table-hover">
					<thead>
						<tr>
							<th>No</th>
							<th>Judul</th>
							<th>Gambar</th>
							<th>Tgl</th>
							<th>Aksi</th>
						</tr>
					</thead>
					<tbody>
					<?php  foreach ($dt as $key => $data) { ?>
						<tr>
							<td><?php echo $key+1; ?></td>
							<td><?php echo $data['judul_presentasi']; ?></td>
							<td>
								<img src="<?php echo base_url("assets/pre-gambar"); ?>/<?php echo $data['gambar']; ?>" width="150">
							</td>
							<td><?php echo $data['tgl_presentasi']; ?></td>
							<td>
								<a href="<?php echo base_url('admin/presentasiedit'); ?>/<?php echo $data['id_presentasi']; ?>" class="btn btn-success btn-xs"><i class="fa fa-edit"></i> Edit</a>
								<a href="<?php echo base_url('presentasi/view'); ?>/<?php echo $data['id_presentasi']; ?>/<?php echo $data['slug_url']; ?>" class="btn btn-primary btn-xs"><i class="fa fa-search"></i> View</a>
								<a href="<?php echo base_url('prosesadmin/presentasidelete'); ?>/<?php echo $data['id_presentasi']; ?>" class="btn btn-danger btn-xs" onclick="return confirm('Lanjutkan menghapus!');"><i class="fa fa-trash"></i> Hapus</a>
							</td>
						</tr>
					<?php } ?>
					</tbody>
				</table>
			</div>
			<div class="box-footer">
				<a href="<?php echo base_url("admin/presentasiadd"); ?>" class="btn btn-info"><i class="fa fa-plus"></i> Tambah Data</a>
			</div>
		</div>
	</div>
</div>
