<div class="row">
	<div class="col-md-12 col-sm-12">
		<div class="box">
			<div class="box-header">
				<h2 class="box-title">Data Konfirmasi</h2>
			</div>
			<div class="box-body">
				<?php echo $this->session->flashdata("pesandonasi"); ?>
				<div class="table-responsive">
					<table id="tableku" class="table table-hover">
						<thead>
							<tr>
								<th>No</th>
								<th>Nama</th>
								<th>Alamat</th>
								<th>No Hp Ooredoo</th>
								<th>Bukti Transfer</th>
								<th>Aksi</th>
							</tr>
						</thead>
						<tbody>
						<?php  foreach ($dt_dk as $key => $data) { ?>
							<tr>
								<td><?php echo $key+1; ?></td>
								<td><?php echo $data['nama_lengkap']; ?></td>
								<td><?php echo $data['alamat']; ?></td>
								<td><?php echo $data['no_hp_oredo']; ?></td>
								<td>
								<a href="<?php echo base_url('assets/img-bukti')."/".$data['bukti_transfer']; ?>" class="thumbnail" data-lightbox="gallery" data-title="Bukti Transfer">
	                    			<img src="<?php echo base_url('assets/img-bukti')."/".$data['bukti_transfer']; ?>" alt="Bukti Transfer" width="150">
	                  			</a>
								</td>
								<td>
									<a href="<?php echo base_url('prosesmember/konfirmasipembayarandonasi'); ?>/<?php echo $data['id_detail_kolom']; ?>/<?php echo $data['id_konfirmasi_kolom']; ?>" class="btn btn-success" onclick="return confirm('Apakah Anda yakin ingin mengkonfirmasi?');"><i class="fa fa-check"></i> Konfirmasi</a>
									<a href="<?php echo base_url('prosesmember/rejectpembayarandonasi'); ?>/<?php echo $data['id_detail_kolom']; ?>/<?php echo $data['id_konfirmasi_kolom']; ?>" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin mereject?');"><i class="fa fa-remove"></i> Reject</a>
								</td>
							</tr>
						<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>