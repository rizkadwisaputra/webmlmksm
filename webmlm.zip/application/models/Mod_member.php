<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mod_member extends CI_Model {
	public function LoginCek($username,$pass){
		$cek = $this->db->query("SELECT * FROM member_akun ma JOIN member m ON ma.id_member = m.id_member 
								WHERE ma.username='$username' AND ma.password='$pass'");
		return $cek;
	}
	public function MemberView($where = ""){
		$res = $this->db->query("SELECT * FROM member m JOIN posisi p ON m.id_posisi=p.id_posisi $where");
		return $res;
	}
	public function AkunView($where = ""){
		$res = $this->db->query("SELECT * FROM member_akun $where");
		return $res;
	}
	public function KonfirmasiDonasiView($where = ""){
		$res = $this->db->query("SELECT * FROM konfirmasi_kolom kk JOIN detail_kolom dk 
								ON kk.id_detail_kolom = dk.id_detail_kolom
								JOIN kolom k ON k.id_kolom = dk.id_kolom 
								JOIN member m ON k.id_member = m.id_member $where");
		return $res;
	}
	public function JaringanView($where = ""){
		$res = $this->db->query("SELECT * FROM referral r
								JOIN member m ON m.id_referral=r.id_referral
								JOIN posisi p ON m.id_posisi = p.id_posisi $where");
		return $res;
	}
	public function CekJaringan($kdsponsor){
		$dt = $this->db->query("SELECT * FROM referral WHERE kd_sponsor='$kdsponsor'");
		$res = $dt->num_rows();
		return $res;	
	}
	public function InsertData($tabel,$data){
		$add = $this->db->insert($tabel,$data);
		return $add;
	}
	public function UpdateData($tabel,$data,$where){
		$up = $this->db->update($tabel,$data,$where);
		return $up;
	}
	public function DeleteData($tabel,$where){
		$del = $this->db->delete($tabel,$where);
		return $del;
	}
}
?>