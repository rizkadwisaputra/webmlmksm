<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mod_admin extends CI_Model {
	public function LoginCek($username,$password){
		$pass = md5($password);
		$cek = $this->db->query("SELECT * FROM admin WHERE username='$username' AND password='$pass'");
		return $cek;
	}
	public function PosisiView($where = "")
	{
		$res = $this->db->query("SELECT * FROM posisi $where");
		return $res;
	}
	public function KecamatanView($where = "")
	{
		$res = $this->db->query("SELECT * FROM kecamatan k JOIN kabupaten kb ON k.id_kabupaten = kb.id_kabupaten $where");
		return $res;
	}
	public function DesaView($where = "")
	{
		$res = $this->db->query("SELECT * FROM desa d JOIN kecamatan k ON d.id_kecamatan = k.id_kecamatan 
								JOIN kabupaten kb ON k.id_kabupaten = kb.id_kabupaten $where");
		return $res;
	}
	public function CekSponsorDaftar($sponsor){

		$res = $this->db->query("SELECT * FROM referral WHERE kd_sponsor='$sponsor'")->num_rows();
		$res2 = $this->db->query("SELECT * FROM member m JOIN posisi p ON m.id_posisi=p.id_posisi 
								WHERE kd_sponsor='$sponsor' AND p.nama_posisi!='Support System'")->num_rows();
		if ($res == 5 || $res > 5 || $res2 == 0 || $res2 > 1) {
			return false;
		}
		else{
			return true;
		}
	}
	public function CekUsername($username){
		$id = $this->session->userdata("idmember");
		$res = $this->db->query("SELECT * FROM member_akun WHERE username='$username' AND id_member!='$id'")->num_rows();
		if ($res > 0) {
			return false;
		}else{
			return true;
		}
	}
	public function MemberView($where =""){
		$res = $this->db->query("SELECT * FROM member m JOIN posisi p ON m.id_posisi = p.id_posisi $where");
		return $res;	
	}
	public function CekKodeSponsor($idmem){
		$dt = $this->db->query("SELECT kd_sponsor FROM member WHERE id_member='$idmem'")->row_array();
		if ($dt['kd_sponsor'] == "") {
			return false;
		}else{
			return true;
		}
			
	}
	public function MemberDetailView($where =""){
		$res = $this->db->query("SELECT * FROM member m JOIN posisi p ON m.id_posisi = p.id_posisi 
								JOIN member_akun ma ON m.id_member = ma.id_member $where");
		return $res;	
	}
	public function BuatKodeSponsor($id_member){

		$qry = $this->db->query("SELECT MAX(kd_sponsor) as kd FROM member");
		$jum = $qry->num_rows();
		$kd = "KSM";
		if ($jum > 0) {
			$data = $qry->row_array();
			$nilaikode = substr($data['kd'],3);
		   // menjadikan $nilaikode ( int )
		   $kode = (int) $nilaikode;
		   // setiap $kode di tambah 1
		   $kode = $kode + 1;
		   $kode_otomatis = $kd.str_pad($kode, 5, "0", STR_PAD_LEFT);
		}else{
			$kode_otomatis = $kd."00001";
		}
		$data_mem = array(
			"kd_sponsor"=>$kode_otomatis
		);
		$res = $this->db->update("member",$data_mem,"id_member=$id_member");
		return $res;
	}
	public function NominalTagihan(){
		$qry = $this->db->query("SELECT nominal_tagihan as nl FROM pembayaran_pendaftaran ORDER BY id_pembayaran_pendaftaran DESC LIMIT 1");
		$jum = $qry->num_rows();
		if ($jum > 0) {
			$dt = $qry->row_array();
			if ($dt['nl']=="150999") {
				$tagihan = "150001";
			}
			else if($dt['nl'] >"160000"){
				$tagihan = "150001";	
			}
			else{
				$tagihan = $dt['nl'] + 1;
			}
		}else{
			$tagihan = "150001";
		}
		return $tagihan;
	}
	public function MemberBelumLunasView($where =""){
		$res = $this->db->query("SELECT * FROM member m JOIN pembayaran_pendaftaran pp ON m.id_member=pp.id_member 
								JOIN posisi pos ON m.id_posisi = pos.id_posisi $where");
		return $res;
	}
	public function PembayaranView($where=""){
		$res = $this->db->query("SELECT * FROM pembayaran_pendaftaran pem JOIN member m ON pem.id_member=m.id_member 
								JOIN posisi p ON p.id_posisi=m.id_posisi $where");
		return $res;
	}
	public function KonfirmasiPembayaranView($where=""){
		$res = $this->db->query("SELECT * FROM konfirmasi_pem_pendaftaran kon 
								JOIN pembayaran_pendaftaran pem 
								ON kon.id_pembayaran_pendaftaran=pem.id_pembayaran_pendaftaran $where");
		return $res;
	}
	public function ReferralView($where = ""){
		$res = $this->db->query("SELECT * FROM referral $where");
		return $res;
	}
	public function KolomView($where = ""){
		$res = $this->db->query("SELECT * FROM kolom $where");
		return $res;
	}
	public function DetailKolomView($where = ""){
		$res = $this->db->query("SELECT * FROM detail_kolom dk 
								JOIN member m ON dk.kd_sponsor=m.kd_sponsor 
								JOIN kolom k ON k.id_kolom = dk.id_kolom $where");
		return $res;
	}
	public function KonfirmasiKolomView($where = ""){
		$res = $this->db->query("SELECT * FROM konfirmasi_kolom kk 
								JOIN detail_kolom dk ON kk.id_detail_kolom=dk.id_detail_kolom $where");
		return $res;
	}
	public function PageView($where = ""){
		$res = $this->db->query("SELECT * FROM page $where");
		return $res;
	}
	public function InformasiView($where = ""){
		$res = $this->db->query("SELECT * FROM informasi $where");
		return $res;
	}
	public function PresentasiView($where = ""){
		$res = $this->db->query("SELECT * FROM presentasi $where");
		return $res;
	}
	public function FotoGaleriView($where = ""){
		$res = $this->db->query("SELECT * FROM foto_galeri $where");
		return $res;
	}
	public function PesanView($where = ""){
		$res = $this->db->query("SELECT * FROM pesan $where");
		return $res;
	}

	public function InsertData($tabel,$data){
		$add = $this->db->insert($tabel,$data);
		return $add;
	}
	public function UpdateData($tabel,$data,$where){
		$up = $this->db->update($tabel,$data,$where);
		return $up;
	}
	public function DeleteData($tabel,$where){
		$del = $this->db->delete($tabel,$where);
		return $del;
	}
}
