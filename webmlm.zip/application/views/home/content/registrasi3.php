
<div class="container con-1">
	<div class="row">
		<div class="title">
          <h2 class="title-h2"><strong>Registrasi</strong></h2>
          <hr class="styletitle" />
        </div>
	</div>
	<div class="row">
		<div class="col-md-8">
			<h3><strong>Konfirmasi Pembayaran</strong></h3>
			<br>
			<form method="POST" action="<?php echo base_url("prosesadmin/konfirmasipembayarannew/$idmem/$idpem"); ?>">
				<div class="form-group">
					<label>Nominal Tagihan</label>
					<input type="number" id="tagihan" class="form-control" name="tagihan" readonly="true" value="<?php echo $dt_pem['nominal_tagihan']; ?>" />
				</div>
				<div class="form-group">
					<label>Nama</label>
					<input type="text" name="nama" id="nama" class="form-control" />
				</div>
				<div class="form-group">
					<label>No HP</label>
					<input type="number" name="no_hp" id="no_hp" class="form-control" />
					<p class="text-danger">No HP yang dapat dihubungi, untuk pemberitahuan akun.</p>
				</div>
				<div class="form-group">
					<label>Nama Bank</label>
					<input type="text" name="nama_bank" id="nama_bank" class="form-control" />
				</div>
				<div class="form-group">
					<label>Nominal Bayar</label>
					<input type="number" name="nominal_bayar" id="nominal_bayar" class="form-control" />
				</div>
				<button type="submit" id="formbtn" class="btn btn-success">Prosess</button>
			</form>
			
			<hr>
		</div>
		<div class="col-md-4">
			<h3><strong>Panduan</strong></h3>
			<br>
			<div class="alert alert-warning">
				<label>Step 1</label>
				<p>Isi formulir pendaftaran, Bagian Nomor ID didapatkan dari referral Anda atau orang yang mengajak Anda.</p>
			</div>
			<div class="alert alert-warning">
				<label>Step 2</label>
				<p>Lakukan pembayaran ke rekening Admin sesuai dengan nominal yang tertera pada tabel pembayaran.</p>
			</div>
			<div class="alert alert-info">
				<label>Step 3</label>
				<p>Lakukan konfirmasi pembayaran sesuai dengan nominal yang telah ditentukan, setelah itu Admin akan mengecek pembayaran anda.</p>
			</div>
			<div class="alert alert-warning">
				<label>Step 4</label>
				<p>Setelah melakukan konfirmasi pembayaran tunggu beberapa saat, jika dalam waktu 1x24 jam belum ada notifikasi yang dikirim melalui sms, silahkan hubungi admin ke no hp 085669660604.</p>
			</div>
		</div>
	</div>
</div>
<script>
	function validateText(id){
		if ($('#'+id).val()== null || $('#'+id).val()== "") {
			var div = $('#'+id).closest('div');
			div.addClass("has-error has-feedback");
			return false;
		}
		else{
			var div = $('#'+id).closest('div');
			div.removeClass("has-error has-feedback");
			return true;	
		}
	}
	$(document).ready(function(){
		$("#formbtn").click(function(){
			var tagihan = parseInt($('#tagihan').val());
			var bayar = parseInt($('#nominal_bayar').val());
			if (!validateText('nama')) {
				$('#nama').focus();
				return false;
			}
			else if (!validateText('no_hp')) {
				$('#no_hp').focus();
				return false;
			}
			else if (!validateText('nama_bank')) {
				$('#nama_bank').focus();
				return false;
			}
			else if (!validateText('nominal_bayar')) {
				$('#nominal_bayar').focus();
				return false;
			}
			else if($("#tagihan").val() == null || $("#tagihan").val() ==""){
				alert("Konfirmasi tidak dapat di proses!");
				return false;
			}
			else if (bayar < tagihan) {
				alert("Nominal Bayar Tidak Cukup");
				return false;
			}
			return true;
		});
	});
</script>