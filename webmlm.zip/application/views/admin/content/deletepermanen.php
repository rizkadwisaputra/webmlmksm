<div class="row">
	<div class="col-md-12">
		<div class="alert alert-warning">
			<p>Member yang dihapus tidak dapat di kembalikan datanya, untuk aturan penghapusan member adalah dengan syarat member tidak mempunyai bawahan. jika misal kita ingin menghapus member A tetapi member A mempunyai bawahan member B dan C maka kita harus menghapus member B dan C terlebih dahulu.</p>
			<p>Untuk menghapus member dengan cara memasukan Nomor ID member tersebut <strong>Ex: KSM00005</strong></p>
		</div>
		<div class="box">
			<div class="box-header">
				<h2 class="box-title">Delete Permanen</h2>
			</div>
			<div class="box-body">
				<form method="POST" action="<?php echo base_url('Deletemember/set'); ?>" enctype="multipart/form-data" >
				<div class="form-group">
					<label>Kode Referral</label>
					<input type="text" name="noref" id="noref" class="form-control"/>
				</div>
			</div>
			<div class="box-footer">
				<button type="submit" id="formbtn" class="btn btn-success"><i class="fa fa-send"></i> Proses</button>
			</div>
				</form>
		</div>
	</div>
</div>
