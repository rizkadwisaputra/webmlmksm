<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ProsesAdmin extends CI_Controller {

	public function Login(){
		$qry = $this->mod_admin->LoginCek($_POST['username'],$_POST['pass']);
		$cek = $qry->num_rows();
		if ($cek == 0 || $cek > 1) {
			$this->session->set_flashdata('pesanlogin',"<div class='alert alert-danger'>Username / Password Salah!</div>");
			redirect("ksmlogin");
		}else{
			$dt = $qry->row_array();
			$sess = array(
				'idadmin' => $dt['id_admin'],
				'nama' => $dt['nama'],
			);
			$this->session->set_userdata($sess);
			
			redirect("admin/index");
		}
	}
	public function Logout(){
		session_destroy();
		redirect("ksmlogin");
	}
	public function MemberAdd(){
		date_timezone_set("Asia/Jakarta");
		$cek = $this->mod_admin->CekSponsorDaftar($_POST['sponsor']);
		if ($cek == false) {
			$this->session->set_flashdata('pesansponsor',"<div class='alert alert-danger'>Nomor ID Tidak Valid!</div>");
			redirect("admin/memberadd");
		}else{
			//insert referral
			$data_ref = array(
				'kd_sponsor' => $_POST['sponsor']
			);
			$this->mod_admin->InsertData('referral', $data_ref);
			//insert member dengan setatus belum bergabung
			//ambil id referral
			$dt_ref = $this->mod_admin->ReferralView("ORDER BY id_referral DESC LIMIT 1")->row_array();

			$data_mem = array(
				'id_posisi'=>$_POST['posisi'],
				'id_referral'=>$dt_ref['id_referral'],
				'nama_lengkap'=>$_POST['nama'],
				'no_ktp'=>$_POST['no_ktp'],
				'tempat_lahir'=>$_POST['tempat_lahir'],
				'tgl_lahir'=>$_POST['tgl_lahir'],
				'nama_ibu_kandung'=>$_POST['nama_ibu'],
				'alamat'=>$_POST['alamat_lengkap'],
				'no_hp_alternatif'=>$_POST['no_hp_alternatif'],
				'no_hp_oredo'=>$_POST['no_hp'],
				'nama_bank'=>$_POST['nama_bank'],
				'no_rek'=>$_POST['no_rek'],
				'nama_tujuan'=>$_POST['nama_pengiriman'],
				'alamat_tujuan'=>$_POST['alamat_tujuan'],
				'kode_pos'=>$_POST['kode_pos'],
				'no_hp'=>$_POST['no_hp_aktif'],
				'tgl_masuk'=>date("Y-m-d"),
				'status'=>"belum bergabung"
			);
			$this->mod_admin->InsertData('member', $data_mem);
			$dt_mem = $this->mod_admin->MemberView("ORDER BY id_member DESC LIMIT 1")->row_array();
			$tagihan = $this->mod_admin->NominalTagihan();
			$data_pem = array(
				'id_member'=>$dt_mem['id_member'],
				'nominal_tagihan'=>$tagihan,
				'tgl_pembayaran'=>date('Y-m-d'),
				'status'=>'proses'
			);
			$res = $this->mod_admin->InsertData('pembayaran_pendaftaran', $data_pem);

			if ($res == true) {
				redirect('admin/konfirmasipembayaranview');
			}else{
				echo "<h2>Gagal</h2>";
			}
		}
			
	}
	public function KonfirmasiPembayaran($idmem, $idpem){
		$data_kon = array(
			'id_pembayaran_pendaftaran'=>$idpem,
			'nama'=>$_POST['nama'],
			'no_hp'=>$_POST['no_hp'],
			'nama_bank'=>$_POST['nama_bank'],
			'nominal_bayar'=>$_POST['nominal_bayar']
			);
		$this->mod_admin->InsertData("konfirmasi_pem_pendaftaran", $data_kon);
		//update
		$data_pem = array(
			'status' => "lunas"
		);
		$this->mod_admin->UpdateData("pembayaran_pendaftaran", $data_pem, "id_pembayaran_pendaftaran = $idpem");
		$data_mem = array(
			'status' => "bergabung"
		);
		$this->mod_admin->UpdateData("member", $data_mem, "id_member = $idmem");
		//buat akun
		$length = 8;
		$characters = '05vwxyz69abc78defghi34jklm2nopq1rstu';
	    $charactersLength = strlen($characters);
	    $username = '';
	    for ($i = 0; $i < $length; $i++) {
	        $username .= $characters[rand(0, $charactersLength - 1)];
	    }
	    $pass = mt_rand(10000,999999);
	    $data_akun = array(
	    	'id_member'=>$idmem,
	    	'username'=>$username,
	    	'password'=>$pass
	    );
	    $this->NewDonasi($idmem);
	    $res = $this->mod_admin->InsertData('member_akun',$data_akun);
		if ($res == true) {
			//ambil data_akun
			$dt_akun = $this->mod_admin->MemberView("where m.id_member='$idmem'")->row_array();
			$namakirim = $dt_akun['nama_lengkap'];
			$notujuan = $_POST['no_hp'];
			$isipesan = "KSM Notifikasi\n\nPemberitahuan username dan password untuk login ke member area.\nNama: $namakirim\nUsername: $username\nPassword: $pass\n\n*Jangan Balas Sms Ini!";
			$this->KirimSMS($notujuan,$isipesan);
			redirect("admin/memberdetail/$idmem");
		}else{
			echo "<h2>gagal</h2>";
		}
	}
	public function MemberEdit($id){
		$data_mem = array(
			'id_posisi'=>$_POST['posisi'],
			'nama_lengkap'=>$_POST['nama'],
			'no_ktp'=>$_POST['no_ktp'],
			'tempat_lahir'=>$_POST['tempat_lahir'],
			'tgl_lahir'=>$_POST['tgl_lahir'],
			'nama_ibu_kandung'=>$_POST['nama_ibu'],
			'alamat'=>$_POST['alamat_lengkap'],
			'no_hp_alternatif'=>$_POST['no_hp_alternatif'],
			'no_hp_oredo'=>$_POST['no_hp'],
			'nama_bank'=>$_POST['nama_bank'],
			'no_rek'=>$_POST['no_rek'],
			'nama_tujuan'=>$_POST['nama_pengiriman'],
			'alamat_tujuan'=>$_POST['alamat_tujuan'],
			'kode_pos'=>$_POST['kode_pos'],
			'no_hp'=>$_POST['no_hp_aktif']
		);
		$res = $this->mod_admin->UpdateData('member', $data_mem, "id_member ='$id'");

		if ($res == true) {
			redirect("admin/memberdetail/$id");
		}else{
			echo "<h2>Gagal</h2>";
		}
	}
	public function MemberEditProses($id){
		$data_mem = array(
			'id_posisi'=>$_POST['posisi'],
			'nama_lengkap'=>$_POST['nama'],
			'no_ktp'=>$_POST['no_ktp'],
			'tempat_lahir'=>$_POST['tempat_lahir'],
			'tgl_lahir'=>$_POST['tgl_lahir'],
			'nama_ibu_kandung'=>$_POST['nama_ibu'],
			'alamat'=>$_POST['alamat_lengkap'],
			'no_hp_alternatif'=>$_POST['no_hp_alternatif'],
			'no_hp_oredo'=>$_POST['no_hp'],
			'nama_bank'=>$_POST['nama_bank'],
			'no_rek'=>$_POST['no_rek'],
			'nama_tujuan'=>$_POST['nama_pengiriman'],
			'alamat_tujuan'=>$_POST['alamat_tujuan'],
			'kode_pos'=>$_POST['kode_pos'],
			'no_hp'=>$_POST['no_hp_aktif']
		);
		$res = $this->mod_admin->UpdateData('member', $data_mem, "id_member ='$id'");

		if ($res == true) {
			redirect("admin/memberdetail2/$id");
		}else{
			echo "<h2>Gagal</h2>";
		}
	}
	public function MemberAddNew(){
		date_timezone_set("Asia/Jakarta");
		$cek = $this->mod_admin->CekSponsorDaftar($_POST['sponsor']);
		if ($cek == false) {
			$this->session->set_flashdata('pesansponsor',"<div class='alert alert-danger'>Nomor ID Tidak Valid!</div>");
			redirect("registrasi");
		}else{
			//insert referral
			$data_ref = array(
				'kd_sponsor' => $_POST['sponsor']
			);
			$this->mod_admin->InsertData('referral', $data_ref);
			//insert member dengan setatus belum bergabung
			//ambil id referral
			$dt_ref = $this->mod_admin->ReferralView("ORDER BY id_referral DESC LIMIT 1")->row_array();

			$data_mem = array(
				'id_posisi'=>$_POST['posisi'],
				'id_referral'=>$dt_ref['id_referral'],
				'nama_lengkap'=>$_POST['nama'],
				'no_ktp'=>$_POST['no_ktp'],
				'tempat_lahir'=>$_POST['tempat_lahir'],
				'tgl_lahir'=>$_POST['tgl_lahir'],
				'nama_ibu_kandung'=>$_POST['nama_ibu'],
				'alamat'=>$_POST['alamat_lengkap'],
				'no_hp_alternatif'=>$_POST['no_hp_alternatif'],
				'nama_bank'=>$_POST['nama_bank'],
				'no_rek'=>$_POST['no_rek'],
				'nama_tujuan'=>$_POST['nama_pengiriman'],
				'alamat_tujuan'=>$_POST['alamat_tujuan'],
				'kode_pos'=>$_POST['kode_pos'],
				'no_hp'=>$_POST['no_hp_aktif'],
				'tgl_masuk'=>date("Y-m-d"),
				'status'=>"belum bergabung"
			);
			$this->mod_admin->InsertData('member', $data_mem);
			$dt_mem = $this->mod_admin->MemberView("ORDER BY m.id_member DESC LIMIT 1")->row_array();
			$tagihan = $this->mod_admin->NominalTagihan();
			$data_pem = array(
				'id_member'=>$dt_mem['id_member'],
				'nominal_tagihan'=>$tagihan,
				'tgl_pembayaran'=>date('Y-m-d'),
				'status'=>'belum lunas'
			);
			$res = $this->mod_admin->InsertData('pembayaran_pendaftaran', $data_pem);
			$dt_pem = $this->mod_admin->PembayaranView("ORDER BY pem.id_pembayaran_pendaftaran DESC LIMIT 1")->row_array();

			$idmem = $dt_mem['id_member'];
			$idpem= $dt_pem['id_pembayaran_pendaftaran'];
			if ($res == true) {
				redirect("registrasi/step2/$idmem/$idpem");
			}else{
				echo "<h2>Gagal</h2>";
			}
		}
			
	}
	public function KonfirmasiPembayaranNew($idmem, $idpem){
		$data_kon = array(
			'id_pembayaran_pendaftaran'=>$idpem,
			'nama'=>$_POST['nama'],
			'no_hp'=>$_POST['no_hp'],
			'nama_bank'=>$_POST['nama_bank'],
			'nominal_bayar'=>$_POST['nominal_bayar']
			);
		$this->mod_admin->InsertData("konfirmasi_pem_pendaftaran", $data_kon);
		//update
		$data_pem = array(
			'status' => "proses"
		);
		$res = $this->mod_admin->UpdateData("pembayaran_pendaftaran", $data_pem, "id_pembayaran_pendaftaran = $idpem");
		$notujuan = $_POST['no_hp'];
		$isi = "KSM Notifikasi\n\nTerimakasih telah melakukan pendaftaran, saat ini pembayaran Anda dalam proses pengecekan\n\n*Jangan Balas Sms Ini!";
		
		if ($res == true) {
			$this->KirimSMS($notujuan,$isi);
			redirect("registrasi/step4/$idmem");
		}else{
			echo "gagal";
		}
	}
	
	public function NewDonasi($idmem){
		$data_kolom = array(
			'id_member'=>$idmem,
			'status_kolom'=>'proses'
		);
		$this->mod_admin->InsertData("kolom",$data_kolom);
		//ambil kolom 
		$dt_kol = $this->mod_admin->KolomView("ORDER BY id_kolom DESC LIMIT 1")->row_array();
		$idkol = $dt_kol['id_kolom'];
		//1
		$dt_mem = $this->mod_admin->MemberView("WHERE m.id_member = '$idmem'")->row_array();
		$ref1 = $dt_mem['id_referral'];
		$dt_ref1 = $this->mod_admin->ReferralView("where id_referral='$ref1'")->row_array();
		$sp1 = $dt_ref1['kd_sponsor'];
		$data_dkol1 = array(
			'no'=>'1',
			'id_kolom'=>$idkol,
			'kd_sponsor'=>$sp1,
			'status_donasi'=>"belum lunas"
		);
		$this->mod_admin->InsertData("detail_kolom", $data_dkol1);
		//2
		$dt_mem2 = $this->mod_admin->MemberView("WHERE m.kd_sponsor = '$sp1'")->row_array();
		$ref2 = $dt_mem2['id_referral'];
		$dt_ref2 = $this->mod_admin->ReferralView("where id_referral='$ref2'")->row_array();
		$sp2 = $dt_ref2['kd_sponsor'];
		$data_dkol2 = array(
			'no'=>'2',
			'id_kolom'=>$idkol,
			'kd_sponsor'=>$sp2,
			'status_donasi'=>"belum lunas"
		);
		$this->mod_admin->InsertData("detail_kolom", $data_dkol2);
		//3
		$dt_mem3 = $this->mod_admin->MemberView("WHERE m.kd_sponsor = '$sp2'")->row_array();
		$ref3 = $dt_mem3['id_referral'];
		$dt_ref3 = $this->mod_admin->ReferralView("where id_referral='$ref3'")->row_array();
		$sp3 = $dt_ref3['kd_sponsor'];
		$data_dkol3 = array(
			'no'=>'3',
			'id_kolom'=>$idkol,
			'kd_sponsor'=>$sp3,
			'status_donasi'=>"belum lunas"
		);
		$this->mod_admin->InsertData("detail_kolom", $data_dkol3);
		//4
		$dt_mem4 = $this->mod_admin->MemberView("WHERE m.kd_sponsor = '$sp3'")->row_array();
		$ref4 = $dt_mem4['id_referral'];
		$dt_ref4 = $this->mod_admin->ReferralView("where id_referral='$ref4'")->row_array();
		$sp4 = $dt_ref4['kd_sponsor'];
		$data_dkol4 = array(
			'no'=>'4',
			'id_kolom'=>$idkol,
			'kd_sponsor'=>$sp4,
			'status_donasi'=>"belum lunas"
		);
		$this->mod_admin->InsertData("detail_kolom", $data_dkol4);
		//5
		$dt_mem5 = $this->mod_admin->MemberView("WHERE m.kd_sponsor = '$sp4'")->row_array();
		$ref5 = $dt_mem5['id_referral'];
		$dt_ref5 = $this->mod_admin->ReferralView("where id_referral='$ref5'")->row_array();
		$sp5 = $dt_ref5['kd_sponsor'];
		$data_dkol5 = array(
			'no'=>'5',
			'id_kolom'=>$idkol,
			'kd_sponsor'=>$sp5,
			'status_donasi'=>"belum lunas"
		);
		$this->mod_admin->InsertData("detail_kolom", $data_dkol5);
	}
	public function KonfirmasiPembayaranAuto($idmem, $idpem){
		//update
		$data_pem = array(
			'status' => "lunas"
		);
		$this->mod_admin->UpdateData("pembayaran_pendaftaran", $data_pem, "id_pembayaran_pendaftaran = $idpem");
		$data_mem = array(
			'no_hp_oredo'=>$_POST['no_hp_oredo'],
			'status' => "bergabung"
		);
		$this->mod_admin->UpdateData("member", $data_mem, "id_member = $idmem");
		//buat akun
		$length = 8;
		$characters = '05vwxyz69abc78defghi34jklm2nopq1rstu';
	    $charactersLength = strlen($characters);
	    $username = '';
	    for ($i = 0; $i < $length; $i++) {
	        $username .= $characters[rand(0, $charactersLength - 1)];
	    }
	    $pass = mt_rand(10000,999999);
	    $data_akun = array(
	    	'id_member'=>$idmem,
	    	'username'=>$username,
	    	'password'=>$pass
	    );
	    $this->NewDonasi($idmem);
	    $res = $this->mod_admin->InsertData('member_akun',$data_akun);
		if ($res == true) {
			$dt_hp = $this->mod_admin->KonfirmasiPembayaranView("where kon.id_pembayaran_pendaftaran='$idpem'")->row_array();
			$notujuan = $dt_hp['no_hp'];

			$dt_akun = $this->mod_admin->MemberView("where m.id_member='$idmem'")->row_array();
			$namakirim = $dt_akun['nama_lengkap'];
			$isipesan = "KSM Notifikasi\n\nPemberitahuan username dan password untuk login ke member area.\nNama: $namakirim\nUsername: $username\nPassword: $pass\n\n*Jangan Balas Sms Ini!";
			$this->KirimSMS($notujuan,$isipesan);
			redirect("admin/memberdetail/$idmem");
		}else{
			echo "<h2>gagal</h2>";
		}
	}
	public function RejectMemberPendaftaran($id){
		$dt_mem = $this->mod_admin->MemberView("where m.id_member='$id'")->row_array();
		$id_ref = $dt_mem['id_referral'];
		$dt_pem = $this->mod_admin->PembayaranView("where pem.id_member = '$id'");
		$jumpem = $dt_pem->num_rows();
		$dtp = $dt_pem->row_array();
		$idpem = $dtp['id_pembayaran_pendaftaran'];
		//hapus konfirmasi dan pembayaran
		if ($jumpem > 0) {
			//delete konfirmasi
			$this->mod_admin->DeleteData("konfirmasi_pem_pendaftaran","id_pembayaran_pendaftaran = $idpem");
			//delete pembayaran
			$this->mod_admin->DeleteData("pembayaran_pendaftaran","id_pembayaran_pendaftaran=$idpem");
		}
		$this->mod_admin->DeleteData("referral", "id_referral=$id_ref");
		
		$res = $this->mod_admin->DeleteData("member", "id_member=$id");
		if ($res==true) {
			redirect("admin/konfirmasipembayaranauto");
		}
	}
	public function MemberDeleteDaftar($id){
		$dt_mem = $this->mod_admin->MemberView("where m.id_member='$id'")->row_array();
		$id_ref = $dt_mem['id_referral'];
		$dt_pem = $this->mod_admin->PembayaranView("where pem.id_member = '$id'");
		$jumpem = $dt_pem->num_rows();
		$dtp = $dt_pem->row_array();
		$idpem = $dtp['id_pembayaran_pendaftaran'];
		//hapus konfirmasi dan pembayaran
		if ($jumpem > 0) {
			//delete konfirmasi
			$this->mod_admin->DeleteData("konfirmasi_pem_pendaftaran","id_pembayaran_pendaftaran = $idpem");
			//delete pembayaran
			$this->mod_admin->DeleteData("pembayaran_pendaftaran","id_pembayaran_pendaftaran=$idpem");
		}
		$this->mod_admin->DeleteData("referral", "id_referral=$id_ref");
		
		$res = $this->mod_admin->DeleteData("member", "id_member=$id");
		if ($res==true) {
			redirect("admin/memberbelumterdaftar");
		}	
	}
	public function MemberDeleteProses($id){
		$dt_mem = $this->mod_admin->MemberView("where m.id_member='$id'")->row_array();
		$id_ref = $dt_mem['id_referral'];
		$dt_pem = $this->mod_admin->PembayaranView("where pem.id_member = '$id'");
		$jumpem = $dt_pem->num_rows();
		$dtp = $dt_pem->row_array();
		$idpem = $dtp['id_pembayaran_pendaftaran'];
		//hapus konfirmasi dan pembayaran
		if ($jumpem > 0) {
			//delete konfirmasi
			$this->mod_admin->DeleteData("konfirmasi_pem_pendaftaran","id_pembayaran_pendaftaran = $idpem");
			//delete pembayaran
			$this->mod_admin->DeleteData("pembayaran_pendaftaran","id_pembayaran_pendaftaran=$idpem");
		}
		$this->mod_admin->DeleteData("referral", "id_referral=$id_ref");
		$this->mod_admin->DeleteData("member_akun", "id_member=$id");
		$res = $this->mod_admin->DeleteData("member", "id_member=$id");
		if ($res==true) {
			redirect("admin/memberproses");
		}	
	}
	//for web
	public function PageEdit($id){
		$data_page = array(
			"judul_page"=>$_POST['judul'],
			"isi"=>$_POST['isi'],
			"deskripsi"=>$_POST['deskripsi'],
			"kata_kunci"=>$_POST['kata_kunci']
		);
		$res = $this->mod_admin->UpdateData("page",$data_page,"id_page=$id");
		if ($res==true) {
			redirect("admin/pageview");
		}
	}
	//informasi
	public function InformasiAdd(){
		date_default_timezone_set("Asia/Jakarta");
		$slug =$this->SlugUrl($_POST['judul']);
		$rand = rand(10,1000);
		$data = array(
			"judul_informasi"=>$_POST['judul'],
			"gambar"=>$rand.$_FILES['gambar']['name'],
			"isi"=>$_POST['isi'],
			"tgl_informasi"=>date("Y-m-d"),
			"slug_url"=>$slug,
			"deskripsi"=>$_POST['deskripsi'],
			"kata_kunci"=>$_POST['kata_kunci']
		);
		//upload
		$nama_file = $rand.$_FILES['gambar']['name'];
		$lokasi_file = $_FILES['gambar']['tmp_name'];
		move_uploaded_file($lokasi_file, "assets/inf-gambar/$nama_file");
		$res = $this->mod_admin->InsertData("informasi",$data);
		if ($res==true) {
			redirect("admin/informasiview");
		}
	}
	public function InformasiEdit($id){
		$slug =$this->SlugUrl($_POST['slug']);
		$rand = rand(10,1000);
		$nama_file = $rand.$_FILES['gambar']['name'];
		$lokasi_file = $_FILES['gambar']['tmp_name'];
		if (!empty($lokasi_file)) {
			$gambarlama = $_POST['nama_gambar'];
			$data = array(
				"judul_informasi"=>$_POST['judul'],
				"gambar"=>$nama_file,
				"isi"=>$_POST['isi'],
				"slug_url"=>$slug,
				"deskripsi"=>$_POST['deskripsi'],
				"kata_kunci"=>$_POST['kata_kunci']
			);
			//delete gambar
			unlink("assets/inf-gambar/$gambarlama");
			//upload
			move_uploaded_file($lokasi_file, "assets/inf-gambar/$nama_file");
			
		}else{
			$data = array(
				"judul_informasi"=>$_POST['judul'],
				"isi"=>$_POST['isi'],
				"slug_url"=>$slug,
				"deskripsi"=>$_POST['deskripsi'],
				"kata_kunci"=>$_POST['kata_kunci']
			);
		}
		$res = $this->mod_admin->UpdateData("informasi",$data,"id_informasi=$id");
		if ($res==true) {
			redirect("admin/informasiview");
		}
	}
	public function InformasiDelete($id){
		$dt = $this->mod_admin->InformasiView("where id_informasi='$id'")->row_array();
		$nama_gambar = $dt['gambar'];
		unlink("assets/inf-gambar/$nama_gambar");
		$res = $this->mod_admin->DeleteData("informasi","id_informasi=$id");
		if ($res==true) {
			redirect("admin/informasiview");
		}else{
			echo "gagal";
		}
	}
	//presentasi
	public function PresentasiAdd(){
		date_default_timezone_set("Asia/Jakarta");
		$slug =$this->SlugUrl($_POST['judul']);
		$rand = rand(10,1000);
		$data = array(
			"judul_presentasi"=>$_POST['judul'],
			"gambar"=>$rand.$_FILES['gambar']['name'],
			"isi"=>$_POST['isi'],
			"tgl_presentasi"=>date("Y-m-d"),
			"slug_url"=>$slug
		);
		//upload
		$nama_file = $rand.$_FILES['gambar']['name'];
		$lokasi_file = $_FILES['gambar']['tmp_name'];
		move_uploaded_file($lokasi_file, "assets/pre-gambar/$nama_file");
		$res = $this->mod_admin->InsertData("presentasi",$data);
		if ($res==true) {
			redirect("admin/presentasiview");
		}else{
			echo "Gagil";
		}
	}
	public function PresentasiEdit($id){
		$slug =$this->SlugUrl($_POST['slug']);
		$rand = rand(10,1000);
		$nama_file = $rand.$_FILES['gambar']['name'];
		$lokasi_file = $_FILES['gambar']['tmp_name'];
		if (!empty($lokasi_file)) {
			$gambarlama = $_POST['nama_gambar'];
			$data = array(
				"judul_presentasi"=>$_POST['judul'],
				"gambar"=>$nama_file,
				"isi"=>$_POST['isi'],
				"slug_url"=>$slug
			);
			//delete gambar
			unlink("assets/pre-gambar/$gambarlama");
			//upload
			move_uploaded_file($lokasi_file, "assets/pre-gambar/$nama_file");
			
		}else{
			$data = array(
				"judul_presentasi"=>$_POST['judul'],
				"isi"=>$_POST['isi'],
				"slug_url"=>$slug
			);
		}
		$res = $this->mod_admin->UpdateData("presentasi",$data,"id_presentasi=$id");
		if ($res==true) {
			redirect("admin/presentasiview");
		}
	}
	public function PresentasiDelete($id){
		$dt = $this->mod_admin->PresentasiView("where id_presentasi='$id'")->row_array();
		$nama_gambar = $dt['gambar'];
		unlink("assets/pre-gambar/$nama_gambar");
		$res = $this->mod_admin->DeleteData("presentasi","id_presentasi=$id");
		if ($res==true) {
			redirect("admin/presentasiview");
		}else{
			echo "gagal";
		}
	}
	//fotogaleri
	public function FotoGaleriAdd(){
		date_default_timezone_set("Asia/Jakarta");
		$rand = rand(10,1000);
		$data = array(
			"judul_foto"=>$_POST['judul'],
			"foto"=>$rand.$_FILES['gambar']['name'],
			"tgl_foto"=>date("Y-m-d"),
		);
		//upload
		$nama_file = $rand.$_FILES['gambar']['name'];
		$lokasi_file = $_FILES['gambar']['tmp_name'];
		move_uploaded_file($lokasi_file, "assets/foto-galeri/$nama_file");
		$res = $this->mod_admin->InsertData("foto_galeri",$data);
		if ($res==true) {
			redirect("admin/fotogaleriview");
		}else{
			echo "Gagal";
		}
	}
	public function FotoGaleriDelete($id){
		$dt = $this->mod_admin->FotoGaleriView("where id_foto_galeri='$id'")->row_array();
		$nama_gambar = $dt['foto'];
		unlink("assets/foto-galeri/$nama_gambar");
		$res = $this->mod_admin->DeleteData("foto_galeri","id_foto_galeri=$id");
		if ($res==true) {
			redirect("admin/fotogaleriview");
		}else{
			echo "gagal";
		}
	}

	public function PesanDelete($id){
		$res = $this->mod_admin->DeleteData("pesan","id_pesan=$id");
		if ($res==true) {
			redirect("admin/pesanview");
		}else{
			echo "gagal";
		}
	}
	//function slug
	private function SlugUrl($str){
		$slug = preg_replace("/[^a-zA-Z0-9-]+/", '-', $str);
		$slug_url = strtolower($slug);
		return $slug_url;
	}
	//sms
	public function KirimSMS($telepon,$message){
		$userkey="novu9f"; // userkey lihat di zenziva
		$passkey="ksm12345"; // set passkey di zenziva

		$url = "https://reguler.zenziva.net/apps/smsapi.php";
		$curlHandle = curl_init();

		curl_setopt($curlHandle, CURLOPT_URL, $url);
		curl_setopt($curlHandle, CURLOPT_POSTFIELDS, 'userkey='.$userkey.'&passkey='.$passkey.'&nohp='.$telepon.'&pesan='.urlencode($message));
		curl_setopt($curlHandle, CURLOPT_HEADER, 0);
		curl_setopt($curlHandle, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($curlHandle, CURLOPT_SSL_VERIFYHOST, 2);
		curl_setopt($curlHandle, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($curlHandle, CURLOPT_TIMEOUT,30);
		curl_setopt($curlHandle, CURLOPT_POST, 1);

		$results = curl_exec($curlHandle);
		curl_close($curlHandle);
	}
}
