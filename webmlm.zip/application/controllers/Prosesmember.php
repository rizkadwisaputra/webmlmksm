<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ProsesMember extends CI_Controller {

	public function Login(){
		$qry = $this->mod_member->LoginCek($_POST['username'],$_POST['pass']);
		$cek = $qry->num_rows();
		if ($cek == 0 || $cek > 1) {
			$this->session->set_flashdata('pesanlogin',"<div class='alert alert-danger'>Username / Password Salah!</div>");
			redirect("mlogin");
		}else{
			$dt = $qry->row_array();
			$sess = array(
				'idmember' => $dt['id_member'],
				'username' => $dt['username'],
				'kdsponsor'=> $dt['kd_sponsor']
			);
			$this->session->set_userdata($sess);
			redirect("member/index");
		}
	}
	public function Logout(){
		session_destroy();
		redirect("mlogin");
	}
	public function UbahPasswordUser(){
		//cek dulu
		$cek = $this->mod_admin->CekUsername($_POST['username']);
		if ($cek == false) {
			$this->session->set_flashdata("pesan","<div class='alert alert-danger'>Username sudah tersedia!</div>");
			redirect("member/ubahpassworduser");
		}
		$idmem = $this->session->userdata("idmember");
		$data_up = array(
			"username"=>$_POST['username'],
			"password"=>$_POST['password']
		);
		$res = $this->mod_member->UpdateData("member_akun",$data_up,"id_member=$idmem");
		if ($res==true) {
			$this->session->set_flashdata('pesan',"<div class='alert alert-success'>Data berhasil dirubah!</div>");
			redirect("member/profile");
		}else{
			echo "gagal";
		}
	}
	public function KonfirmasiDonasi($id_dk){
		date_default_timezone_set("Asia/Jakarta");
		// $datetime = new DateTime('tomorrow');
		// $datetime->format('Y-m-d');
		$rand = rand(10,1000);
		$data_up = array(
			"status_donasi"=>"proses"
		);
		$this->mod_member->UpdateData("detail_kolom",$data_up,"id_detail_kolom=$id_dk");
		$data_kon = array(
			"id_detail_kolom"=>$id_dk,
			"tgl_konfirmasi"=>date("Y-m-d"),
			"bukti_transfer"=>$rand.$_FILES['bukti']['name'],
			"status_konfirmasi"=>"proses"
		);
		$nama_file = $rand.$_FILES['bukti']['name'];
		$lokasi_file = $_FILES['bukti']['tmp_name'];
		move_uploaded_file($lokasi_file, "assets/img-bukti/$nama_file");
		$res = $this->mod_member->InsertData("konfirmasi_kolom",$data_kon);
		if ($res == true) {
			$dt_dk = $this->mod_admin->DetailKolomView("where dk.id_detail_kolom='$id_dk'")->row_array();
			$kdsponsor = $dt_dk['kd_sponsor'];
			$id_kolom = $dt_dk['id_kolom'];
			//ambil kolom 
			$dt_kol = $this->mod_admin->KolomView("where id_kolom='$id_kolom'")->row_array();
			$idpendonasi = $dt_kol['id_member'];
			//data pendonasi
			$dt_pendonasi = $this->mod_admin->MemberView("where m.id_member='$idpendonasi'")->row_array();
			$namapendonasi = $dt_pendonasi['nama_lengkap'];
			//ambil member
			$dt_mem = $this->mod_admin->MemberView("where m.kd_sponsor='$kdsponsor'")->row_array();
			$notujuan = $dt_mem['no_hp_alternatif'];
			$isipesan = "KSM Notifikasi\n\n$namapendonasi telah memberikan donasi Rp 100.000 kepada Anda, harap segera login ke member area untuk mengkonfirmasi donasi.\n\n*Jangan Balas Sms Ini!";
			$resSms = $this->KirimSMS($notujuan,$isipesan);
			if ($resSms == true) {
				redirect("member/donasi");
			}else{
				redirect("member/donasi");;
			}
			
		}else{
			echo "GAGAL";
		}
	}
	public function KonfirmasiPembayaranDonasi($id_dk,$id_kon){
		$data_up = array(
			"status_donasi"=>"lunas"
		);
		$this->mod_member->UpdateData("detail_kolom",$data_up,"id_detail_kolom=$id_dk");
		$data_kon = array(
			"status_konfirmasi"=>"lunas"
		);
		$res = $this->mod_member->UpdateData("konfirmasi_kolom",$data_kon,"id_konfirmasi_kolom=$id_kon");
		//ambil id member cek kode sponsor
		$dt_dk =  $this->mod_admin->DetailKolomView("where dk.id_detail_kolom='$id_dk'")->row_array();
		$id_kolom = $dt_dk['id_kolom'];
		//ambil member
		$dt_kolmem = $this->mod_admin->KolomView("where id_kolom='$id_kolom'")->row_array();
		$id_mem = $dt_kolmem['id_member'];

		//
		if ($res == true) {
			$this->session->set_flashdata('pesandonasi',"<div class='alert alert-success'>Konfirmasi Berhasil!</div>");
			//ambil member 1
			$kdspkon = $dt_dk['kd_sponsor'];
			$dt_memkon = $this->mod_admin->MemberView("where m.kd_sponsor='$kdspkon'")->row_array();
			$namamemkon = $dt_memkon['nama_lengkap'];
			//kirim notifikasi
			$dt_mem2 = $this->mod_admin->MemberView("where m.id_member='$id_mem'")->row_array();
			$notujuan1 = $dt_mem2['no_hp_alternatif'];
			$isipesan1 = "KSM Notifikasi\n\n$namamemkon telah mengkonfirmasi donasi Anda, harap login ke halaman member untuk pengecekan.\n\n*Jangan Balas Sms Ini!";
			$this->KirimSMS($notujuan1,$isipesan1);
			//ceking
			$dt2 = $this->mod_admin->DetailKolomView("where dk.id_kolom ='$id_kolom' and k.id_member='$id_mem' and dk.status_donasi='lunas'");
			$notif2 = $dt2->num_rows();
			if ($notif2 == 5) {
				$data_kol = array(
					"status_kolom"=>"selesai"
				);
				
				
				$this->mod_member->UpdateData("kolom",$data_kol,"id_kolom=$id_kolom");
				$this->mod_admin->BuatKodeSponsor($id_mem);
				//ambil member 2
				$dt_mem = $this->mod_admin->MemberView("where m.id_member='$id_mem'")->row_array();
				$kdsponsor = $dt_mem['kd_sponsor'];
				$notujuan = $dt_mem['no_hp_alternatif'];
				//kirim notif sms
				$isipesan2 = "KSM Notifikasi\n\nSelamat Donasi ke 5 anggota telah terkonfirmasi\nNomor ID Anda = $kdsponsor\n\n*Jangan Balas Sms Ini!";
				$this->KirimSMS($notujuan,$isipesan2);
			}
			//
			redirect("member/konfirmasidonasi");
		}else{
			echo "GAGAL";
		}
	}
	public function RejectPembayaranDonasi($id_dk,$id_kon){
		$data_up = array(
			"status_donasi"=>"belum lunas"
		);
		$this->mod_member->UpdateData("detail_kolom",$data_up,"id_detail_kolom=$id_dk");
		$dt_kon = $this->mod_member->KonfirmasiDonasiView("where kk.id_konfirmasi_kolom='$id_kon'")->row_array();
		$nama_file = $dt_kon['bukti_transfer'];
		unlink("assets/img-bukti/$nama_file");
		//delete
		$res = $this->mod_member->DeleteData("konfirmasi_kolom","id_konfirmasi_kolom=$id_kon");
		if ($res == true) {
			//ambil id member cek kode sponsor
			$dt_dk =  $this->mod_admin->DetailKolomView("where dk.id_detail_kolom='$id_dk'")->row_array();
			$id_kolom = $dt_dk['id_kolom'];
			//ambil member
			$dt_kolmem = $this->mod_admin->KolomView("where id_kolom='$id_kolom'")->row_array();
			$id_mem = $dt_kolmem['id_member'];
			$kdspkon = $dt_dk['kd_sponsor'];
			$dt_memkon = $this->mod_admin->MemberView("where m.kd_sponsor='$kdspkon'")->row_array();
			$namamemkon = $dt_memkon['nama_lengkap'];
			//kirim notifikasi
			$dt_mem2 = $this->mod_admin->MemberView("where m.id_member='$id_mem'")->row_array();
			$notujuan1 = $dt_mem2['no_hp_alternatif'];

			$isipesan1 = "KSM Notifikasi\n\n$namamemkon menggagalkan donasi Anda, harap login ke halaman member untuk pengecekan atau hubungi $namamemkon.\n\n*Jangan Balas Sms Ini!";
			$this->KirimSMS($notujuan1,$isipesan1);
			$this->session->set_flashdata('pesandonasi',"<div class='alert alert-danger'>Konfirmasi Berhasil Digagalkan!</div>");
			redirect("member/konfirmasidonasi");
		}else{
			echo "GAGAL";
		}
	}
	public function KirimSMS($telepon,$message){
		$userkey="novu9f"; // userkey lihat di zenziva
		$passkey="ksm12345"; // set passkey di zenziva

		$url = "https://reguler.zenziva.net/apps/smsapi.php";
		$curlHandle = curl_init();

		curl_setopt($curlHandle, CURLOPT_URL, $url);
		curl_setopt($curlHandle, CURLOPT_POSTFIELDS, 'userkey='.$userkey.'&passkey='.$passkey.'&nohp='.$telepon.'&pesan='.urlencode($message));
		curl_setopt($curlHandle, CURLOPT_HEADER, 0);
		curl_setopt($curlHandle, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($curlHandle, CURLOPT_SSL_VERIFYHOST, 2);
		curl_setopt($curlHandle, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($curlHandle, CURLOPT_TIMEOUT,30);
		curl_setopt($curlHandle, CURLOPT_POST, 1);

		$results = curl_exec($curlHandle);
		curl_close($curlHandle);
	}
}
?>