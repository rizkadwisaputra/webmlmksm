
<div class="row">
	<div class="col-md-12 col-sm-12">
		<div class="alert alert-info">
			<h1 style="margin:0;">Selamat Datang <strong><?php echo $dt_mem['nama_lengkap']; ?></strong></h1>
		</div>
	</div>
	<div class="col-md-12 col-sm-12">
		<?php if ($this->mod_admin->CekKodeSponsor($idmem)== false) {?>
		<div class="alert alert-danger">
			<p><font size="5">Anda belum melakukan donasi ke 5 orang sehingga Anda belum mempunyai Nomor ID.</font></p>
			<p><a href="<?php echo base_url('member/donasi'); ?>" class="btn btn-primary" style="text-decoration:none;">MENU DONASI</a></p>
		</div>
		<?php }else{ ?>
		<div class="alert alert-success">
			<p><font size="5">Nomor ID Anda : <span style="margin-left:5px;"><i><font size="5"><strong><?php echo $kdsponsor; ?></strong></font></i></span></font></p>
		</div>
		<?php } ?>
		<?php if ($notif>0) {?>
		<div class="alert alert-warning">
			<p><font size="5">Notifikasi Konfirmasi Donasi</font></p>
			<p><a href="<?php echo base_url('member/konfirmasidonasi'); ?>" class="btn btn-primary" style="text-decoration:none;">MENU KONFIRMASI DONASI</a></p>
		</div>
		<?php } ?>
	</div>
</div>	