<div class="row">
	<div class="title">
      	<h2 class="title-h2"><strong><?php echo $data['judul_presentasi']; ?></strong></h2>
        <hr class="styletitle" />
    </div>
</div>
<div class="row">
  <div class="col-md-12 col-sm-12">
    
    <?php echo $data['isi']; ?>
  </div>
</div>