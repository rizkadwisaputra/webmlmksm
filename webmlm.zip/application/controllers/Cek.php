<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cek extends CI_Controller {

	public function SponsorDaftar($cek){
		$res = $this->mod_admin->CekSponsorDaftar($cek);
		if ($res == false) {
			echo "<span style='color:red; padding-left:4px;'><i class='fa fa-warning'></i> Nomor ID tidak valid / melebihi batas</span>";
		}else{
			$dt = $this->mod_admin->MemberView("where m.kd_sponsor='$cek'")->row_array();
			$nama = $dt['nama_lengkap'];
			echo "<span style='color:green; padding-left:4px;'><i class='fa fa-check'></i> Nomor ID tersedia</span><br/>";
			echo "<span style='color:green; padding-left:4px;'><i class='fa fa-arrow-right'></i> Nama: $nama</span>";
		}
	}
	public function Username($cek){
		$res = $this->mod_admin->CekUsername($cek);
		if ($res == false) {
			echo "<span style='color:red; padding-left:4px;'><i class='fa fa-warning'></i> Username Sudah Tersedia, Coba yang lain?</span>";
		}else{
			echo "";
		}
	}
}
