<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="<?php echo $deskripsi; ?>">
    <meta name="keywords" content="<?php echo $keywords; ?>">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>KSM | Komunitas Saling Membantu</title>
    <link rel="icon" type="image/png" href="<?php echo base_url('assets/logo/logo.png'); ?>">
    <!-- Bootstrap -->
    <link href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css'); ?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/dist/css/costumweb.css'); ?>" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/owl/css/owl.carousel.css" rel="stylesheet">  
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="<?php echo base_url('assets/plugins/jQuery/jQuery.min.js'); ?>"></script>
  </head>
  <body>
    <div class="top-nav"></div>
    <?php echo $navigasi; ?>
<div class="container con-1">
	
  <?php echo $content; ?>
</div>
    <footer class="footer">
      <div class="container">
        <p class="text-footer">Copyright &copy; 2016 <a href="<?php echo base_url(); ?>">KSM (Komunitas Saling Membantu)</a></p>
      </div>
    </footer>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js'); ?>"></script>
  </body>
</html>