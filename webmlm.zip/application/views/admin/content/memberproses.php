<div class="row">
	<div class="col-md-12 col-sm-12">
		<div class="box">
			<div class="box-header">
				<h2 class="box-title">Data Member</h2>
			</div>
			<div class="box-body">
				<table id="tableku" class="table table-hover">
					<thead>
						<tr>
							<th>No</th>
							<th>Nama</th>
							<th>Tgl Daftar</th>
							<th>Posisi</th>
							<th>Alamat</th>
							<th>No HP OOREDOO</th>
							<th>Aksi</th>
						</tr>
					</thead>
					<tbody>
					<?php  foreach ($dt_mem as $key => $data) { ?>
						<tr>
							<td><?php echo $key+1; ?></td>
							<td><?php echo $data['nama_lengkap']; ?></td>
							<td><?php echo $data['tgl_masuk']; ?></td>
							<td><?php echo $data['nama_posisi']; ?></td>
							<td><?php echo $data['alamat']; ?></td>
							<td><?php echo $data['no_hp_alternatif']; ?></td>
							<td>
								<a href="<?php echo base_url('admin/membereditproses'); ?>/<?php echo $data['id_member']; ?>" class="btn btn-info btn-xs"><i class="fa fa-edit"></i> Edit</a>
								<a href="<?php echo base_url('admin/memberdetail'); ?>/<?php echo $data['id_member']; ?>" class="btn btn-success btn-xs"><i class="fa fa-search"></i> Detail</a>	
							</td>
						</tr>
					<?php } ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>