
<div class="container con-1">
	<div class="row">
		<div class="title">
          <h2 class="title-h2"><strong>Registrasi</strong></h2>
          <hr class="styletitle" />
        </div>
	</div>
	<div class="row">
		<div class="col-md-8">
			<h3><strong>Pembayaran</strong></h3>
			<p>Lakukan pembayaran ke REK Admin:</p>
			<table class="table">
				<tr>
					<td width="20%">Atas Nama</td>
					<td width="1%">:</td>
					<td>Suyadi</td>
				</tr>
				<tr>
					<td width="20%">Bank</td>
					<td width="1%">:</td>
					<td>BCA</td>
				</tr>
				<tr>
					<td width="20%">No REK</td>
					<td width="1%">:</td>
					<td>1170596044</td>
				</tr>
			</table>
			<p>sesuai dengan total nominal yang tertera ditabel slip pembayaran dibawah ini.</p>
			<br>
			<table class="table table-bordered">
				<tr class="info">
					<th colspan="3"><center>Slip Pembayaran</center></th>
				</tr>
				<tr>
					<th>No</th>
					<th>Nama</th>
					<th>Nominal</th>
				</tr>
				<tr>
					<td>1</td>
					<td>Kartu Komunitas</td>
					<td>Rp. <?php echo number_format($nominal); ?></td>
				</tr>
				<tr class="active">
					<td colspan="2"><center><b>Total</b></center></td>
					<td><b>Rp. <?php echo number_format($nominal); ?></b></td>
				</tr>
			</table>
			<a href="<?php echo base_url("registrasi/step3/$idmem/$idpem"); ?>" class="btn btn-success">Lanjutkan Ke Konfirmasi Pembayaran</a>
			<hr>
		</div>
		<div class="col-md-4">
			<h3><strong>Panduan</strong></h3>
			<br>
			<div class="alert alert-warning">
				<label>Step 1</label>
				<p>Isi formulir pendaftaran, Bagian Nomor ID didapatkan dari referral Anda atau orang yang mengajak Anda.</p>
			</div>
			<div class="alert alert-info">
				<label>Step 2</label>
				<p>Lakukan pembayaran ke rekening Admin sesuai dengan nominal yang tertera pada tabel pembayaran.</p>
			</div>
			<div class="alert alert-warning">
				<label>Step 3</label>
				<p>Lakukan konfirmasi pembayaran sesuai dengan nominal yang telah ditentukan, setelah itu Admin akan mengecek pembayaran anda.</p>
			</div>
			<div class="alert alert-warning">
				<label>Step 4</label>
				<p>Setelah melakukan konfirmasi pembayaran tunggu beberapa saat, jika dalam waktu 1x24 jam belum ada notifikasi yang dikirim melalui sms, silahkan hubungi admin ke no hp 085669660604.</p>
			</div>
		</div>
	</div>
</div>