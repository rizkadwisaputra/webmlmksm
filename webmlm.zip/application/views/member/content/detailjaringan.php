<div class="row">
	<div class="col-md-12">
		<div class="box">
			<div class="box-header">
				<h2 class="box-title">Detail Jaringan</h2>
			</div>
			<div class="box-body">
				<table class="table">
					<tr>
						<td width="10%">Nama</td>
						<td width="1%">:</td>
						<td><?php echo $dt['nama_lengkap']; ?></td>
					</tr>
					<tr>
						<td width="10%">No KTP</td>
						<td width="1%">:</td>
						<td><?php echo $dt['no_ktp']; ?></td>
					</tr>
					<tr>
						<td width="10%">Tempat Lahir</td>
						<td width="1%">:</td>
						<td><?php echo $dt['tempat_lahir']; ?></td>
					</tr>
					<tr>
						<td width="10%">Tanggal Lahir</td>
						<td width="1%">:</td>
						<td><?php echo date('d-m-Y', strtotime($dt['tgl_lahir'])); ?></td>
					</tr>
					<tr>
						<td width="10%">Alamat</td>
						<td width="1%">:</td>
						<td><?php echo $dt['alamat']; ?></td>
					</tr>
					<tr>
						<td width="10%">Posisi/Status</td>
						<td width="1%">:</td>
						<td><?php echo $dt['nama_posisi']; ?></td>
					</tr>
					<tr>
						<td width="10%">Nama Bank</td>
						<td width="1%">:</td>
						<td><?php echo $dt['nama_bank']; ?></td>
					</tr>
					<tr>
						<td width="10%">No REK</td>
						<td width="1%">:</td>
						<td><?php echo $dt['no_rek']; ?></td>
					</tr>
					<tr>
						<td width="10%">Nama Ibu</td>
						<td width="1%">:</td>
						<td><?php echo $dt['nama_ibu_kandung']; ?></td>
					</tr>
					<tr>
						<td width="10%">No Hp Alternatif</td>
						<td width="1%">:</td>
						<td><?php echo $dt['no_hp_alternatif']; ?></td>
					</tr>
					<tr>
						<td width="10%">No Hp Ooredoo</td>
						<td width="1%">:</td>
						<td><?php echo $dt['no_hp_oredo']; ?></td>
					</tr>
					<tr>
						<td width="10%">Tgl Daftar</td>
						<td width="1%">:</td>
						<td><?php echo date('d F Y', strtotime($dt['tgl_masuk'])); ?></td>
					</tr>
				</table>
			</div> 	
		</div>
	</div>
</div>