<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Presentasi extends CI_Controller {

	public function index()
	{
		$data = $this->mod_admin->PresentasiView()->result_array();
		$content = array(
			"navigasi" => $this->Navigation(),
			"content"=>$this->load->view("home/presentasi/content/presentasiview",array("dt"=>$data),true)
		);
		$this->load->view('home/presentasi/presentasi',$content);
	}
	public function View($id="",$slug=""){
		if ($slug != "" && $id != "") {
			$data = $this->mod_admin->PresentasiView("where id_presentasi='$id'")->row_array();
			if ($data['slug_url'] == $slug && $data['id_presentasi']==$id) {
				$content = array(
					"navigasi" => $this->Navigation(),
					"content"=>$this->load->view("home/presentasi/content/presentasidetail",array("data"=>$data),true)
				);
				$this->load->view('home/presentasi/presentasi',$content);
			}else{
				$this->load->view("errors/404.html");
			}
		}else{
			$this->load->view("errors/404.html");
		}
	}

	private function Navigation(){
		return $this->load->view('home/navigasi', array(), true);
	}
}
