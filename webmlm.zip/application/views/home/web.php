
    <?php echo $header; ?>
    <?php echo $navigasi; ?>
    
    <?php echo $content; ?>
    <?php echo $footer; ?>