<div class="row">
	<div class="col-md-12 col-sm-12">
		<div class="box">
			<div class="box-header">
				<h2 class="box-title">Page View</h2>
			</div>
			<div class="box-body">
				<table id="tableku" class="table table-hover">
					<thead>
						<tr>
							<th>No</th>
							<th>Judul</th>
							<th>Tgl</th>
							<th>Isi</th>
							<th>Aksi</th>
						</tr>
					</thead>
					<tbody>
					<?php  foreach ($dt as $key => $data) { ?>
						<tr>
							<td><?php echo $key+1; ?></td>
							<td><?php echo $data['judul_page']; ?></td>
							<td><?php echo $data['tgl_page']; ?></td>
							<td><?php echo substr(strip_tags($data['isi']), 0,50); ?></td>
							<td>
								<a href="<?php echo base_url('admin/pageedit'); ?>/<?php echo $data['id_page']; ?>" class="btn btn-success btn-xs"><i class="fa fa-edit"></i> Edit</a>
							</td>
						</tr>
					<?php } ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
