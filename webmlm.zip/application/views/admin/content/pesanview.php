<div class="row">
	<div class="col-md-12 col-sm-12">
		<div class="box">
			<div class="box-header">
				<h2 class="box-title">Data Pesan</h2>
			</div>
			<div class="box-body">
			<?php echo $this->session->flashdata("pesan"); ?>
				<table id="tableku" class="table table-hover">
					<thead>
						<tr>
							<th>No</th>
							<th>Nama</th>
							<th>Email</th>
							<th>Subjek</th>
							<th>Pesan</th>
							<th>Aksi</th>
						</tr>
					</thead>
					<tbody>
					<?php  foreach ($dt as $key => $data) { ?>
						<tr>
							<td><?php echo $key+1; ?></td>
							<td><?php echo $data['nama']; ?></td>
							<td><?php echo $data['email']; ?></td>
							<td><?php echo $data['subjek']; ?></td>
							<td><?php echo substr(strip_tags($data['pesan']), 0,30); ?></td>
							<td>
								<a href="<?php echo base_url('admin/balaspesan'); ?>/<?php echo $data['id_pesan']; ?>" class="btn btn-primary btn-xs"><i class="fa fa-mail-reply"></i>  Balas</a>
								<a href="<?php echo base_url('prosesadmin/pesandelete'); ?>/<?php echo $data['id_pesan']; ?>" class="btn btn-danger btn-xs" onclick="return confirm('Lanjutkan Menghapus!!');"><i class="fa fa-trash"></i>  Hapus</a>
							</td>
						</tr>
					<?php } ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>