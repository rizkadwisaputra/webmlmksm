<div class="row">
	<div class="col-md-12 col-sm-12">
		<div class="alert alert-info">
			<h3 style="margin:3px;">Selamat Datang Admin</h3>
			
		</div>
	</div>
</div>	