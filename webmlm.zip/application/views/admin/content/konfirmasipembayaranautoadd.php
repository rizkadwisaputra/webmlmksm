<div class="row">
	<div class="col-md-12">
		<div class="box">
			<div class="box-header">
				<h2 class="box-title">Konfirmasi Pembayaran</h2>
			</div>
			<div class="box-body">
					<h3>Data Pembayaran</h3>
					<table class="table">
						<tr>
							<td width="10%">Nominal Tagihan</td>
							<td width="1%">:</td>
							<td><?php echo $dt_pem['nominal_tagihan']; ?></td>
						</tr>
					</table>
					<hr\>
					<h3>Data Konfirmasi</h3>
					<table class="table">
						<tr>
							<td width="10%">Nominal Bayar</td>
							<td width="1%">:</td>
							<td><?php echo $dt_kon['nominal_bayar']; ?></td>
						</tr>
						<tr>
							<td width="10%">Nama</td>
							<td width="1%">:</td>
							<td><?php echo $dt_kon['nama']; ?></td>
						</tr>
						<tr>
							<td width="10%">No HP</td>
							<td width="1%">:</td>
							<td><?php echo $dt_kon['no_hp']; ?></td>
						</tr>
						<tr>
							<td width="10%">Nama Bank</td>
							<td width="1%">:</td>
							<td><?php echo $dt_kon['nama_bank']; ?></td>
						</tr>
					</table>
					<hr/>
				<form method="POST" action="<?php echo base_url('prosesadmin/konfirmasipembayaranauto'); ?>/<?php echo $idmem; ?>/<?php echo $idpem; ?>">
					<div class="form-group">
						<label>No HP OOREDOO</label>
						<input type="number" name="no_hp_oredo" id="no_hp_oredo" class="form-control" />
					</div>
			</div>
			<div class="box-footer">
				<button type="submit" id="formbtn" class="btn btn-success"><i class="fa fa-check"></i> Konfirmasi</button>
				
			</div>
				</form>
		</div>
		<div class="box">
			<div class="box-header">
				<h2 class="box-title">Data Member</h2>
			</div>
			<div class="box-body">
				<table class="table">
					<tr>
						<td width="10%">Nama</td>
						<td width="1%">:</td>
						<td><?php echo $dt_pem['nama_lengkap']; ?></td>
					</tr>
					<tr>
						<td width="10%">Nomor ID</td>
						<td width="1%">:</td>
						<td><?php echo $dt_pem['kd_sponsor']; ?></td>
					</tr>
					<tr>
						<td width="10%">No KTP</td>
						<td width="1%">:</td>
						<td><?php echo $dt_pem['no_ktp']; ?></td>
					</tr>
					<tr>
						<td width="10%">Tempat Lahir</td>
						<td width="1%">:</td>
						<td><?php echo $dt_pem['tempat_lahir']; ?></td>
					</tr>
					<tr>
						<td width="10%">Tanggal Lahir</td>
						<td width="1%">:</td>
						<td><?php echo date('d-m-Y', strtotime($dt_pem['tgl_lahir'])); ?></td>
					</tr>
					<tr>
						<td width="10%">Alamat</td>
						<td width="1%">:</td>
						<td><?php echo $dt_pem['alamat']; ?></td>
					</tr>
					<tr>
						<td width="10%">Posisi/Status</td>
						<td width="1%">:</td>
						<td><?php echo $dt_pem['nama_posisi']; ?></td>
					</tr>
					<tr>
						<td width="10%">Sponsor</td>
						<td width="1%">:</td>
						<td><?php echo $dt_sponsor['nama_lengkap']; ?></td>
					</tr>
					<tr>
						<td width="10%">Nama Ibu</td>
						<td width="1%">:</td>
						<td><?php echo $dt_pem['nama_ibu_kandung']; ?></td>
					</tr>
					<tr>
						<td width="10%">No Hp Alternatif</td>
						<td width="1%">:</td>
						<td><?php echo $dt_pem['no_hp_alternatif']; ?></td>
					</tr>
				</table>
				<hr/>
				<h4>Data Pengiriman</h4>
				<br/>
				<table class="table">
					<tr>
						<td width="10%">Nama Pengiriman</td>
						<td width="1%">:</td>
						<td><?php echo $dt_pem['nama_tujuan']; ?></td>
					</tr>
					<tr>
						<td width="10%">Alamat Tujuan</td>
						<td width="1%">:</td>
						<td><?php echo $dt_pem['alamat_tujuan']; ?></td>
					</tr>
					<tr>
						<td width="10%">Kode POS</td>
						<td width="1%">:</td>
						<td><?php echo $dt_pem['kode_pos']; ?></td>
					</tr>
					<tr>
						<td width="10%">No Hp Aktif</td>
						<td width="1%">:</td>
						<td><?php echo $dt_pem['no_hp']; ?></td>
					</tr>
				</table>
			</div>
		</div>
	</div>
</div>
<script>
	function validateText(id){
		if ($('#'+id).val()== null || $('#'+id).val()== "") {
			var div = $('#'+id).closest('div');
			div.addClass("has-error has-feedback");
			return false;
		}
		else{
			var div = $('#'+id).closest('div');
			div.removeClass("has-error has-feedback");
			return true;	
		}
	}
	$(document).ready(function(){
		$("#formbtn").click(function(){
			if (!validateText('no_hp_oredo')) {
				$('#no_hp_oredo').focus();
				return false;
			}
			return true;
		});
	});
</script>