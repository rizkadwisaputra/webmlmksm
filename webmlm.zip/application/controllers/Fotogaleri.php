<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class FotoGaleri extends CI_Controller {

	public function index(){
		$dt = $this->mod_admin->FotoGaleriView()->result_array();
		$content = array(
			"header" => $this->Header(),
			"navigasi" => $this->Navigation(),
			"footer" => $this->Footer(),
			"content" => $this->load->view('home/content/fotogaleri', array('dt'=>$dt), true)
		);
		$this->load->view('home/web.php',$content);
	}

	private function Navigation(){
		return $this->load->view('home/navigasi', array(), true);
	}
	private function Header(){
		return $this->load->view('home/header', array(), true);
	}
	private function Footer(){
		return $this->load->view('home/footer', array(), true);
	}
}
