	<footer class="footer">
      <div class="container">
        <p class="text-footer">Copyright &copy; 2016 <a href="<?php echo base_url(); ?>">KSM (Komunitas Saling Membantu)</a></p>
      </div>
    </footer>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js'); ?>"></script>
    <script src="<?php echo base_url(); ?>assets/owl/owl.carousel.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/plugins/lightbox/js/lightbox.min.js"></script>
    <!-- instalasi owl crausel -->
    <script type="text/javascript">
    	$('.carousel').carousel()
    </script>
    <script type="text/javascript">
      $(document).ready(function(){
        $("#owl").owlCarousel({
          autoplay: 4000, //4 detik
          loop: true,
          margin: 5,
          responsive:{
              0:  { items:2 },
              450:{ items:3 },
              767:{ items:3 },
              991:{ items:4 },
              1199:{ items:4 }
          }
        });
      });
    </script>
    <!-- end owl -->
     <!-- instalasi owl crausel -->
    <script type="text/javascript">
      $(document).ready(function(){
        $("#owl2").owlCarousel({
          autoplay: 4000, //4 detik
          loop: true,
          margin: 5,
          responsive:{
              0:  { items:2 },
              450:{ items:3 },
              767:{ items:3 },
              991:{ items:4 },
              1199:{ items:4 }
          }
        });
      });
    </script>
    <script type="text/javascript">
      $(document).ready(function(){
        $("#owl3").owlCarousel({
          autoplay: 4000, //4 detik
          loop: true,
          margin: 5,
          responsive:{
              0:  { items:2 },
              450:{ items:3 },
              767:{ items:3 },
              991:{ items:4 },
              1199:{ items:4 }
          }
        });
      });
    </script>
    <script type="text/javascript">
      $(document).ready(function(){
        $('body').prepend("<a href='' class='b-top'></a>");
        $(window).scroll(function(){
          if ($(window).scrollTop() > 250) {
            $('a.b-top').fadeIn('slow');
          }else{
            $('a.b-top').fadeOut('slow');
          }
        });
        $('a.b-top').click(function(){
          $('body').animate({
            scrollTop: 0
          }, 'slow');
          return false;
        });
      });
    </script>
  </body>
</html>