<div class="row">
	<div class="col-md-12">
		<div class="box">
			<div class="box-header">
				<h2 class="box-title">Konfirmasi Donasi</h2>
			</div>
			<div class="box-body">
				<form method="post" action="<?php echo base_url('prosesmember/konfirmasidonasi'); ?>/<?php echo $id_dk; ?>" enctype="multipart/form-data">
					<div class="form-group">
						<label>Bukti Transfer</label>
						<input type="file" id="bukti" name="bukti" class="form-control">
						<p class="text-info">* Bukti transfer bisa berupa foto atau screenshot</p>
					</div>
			</div>
			<div class="box-footer">
				<button type="submit" id="formbtn" class="btn btn-info">Konfirmasi</button>
				</form>
			</div>
		</div>
	</div>
</div>

<script>
	function validateText(id){
		if ($('#'+id).val()== null || $('#'+id).val()== "") {
			var div = $('#'+id).closest('div');
			div.addClass("has-error has-feedback");
			return false;
		}
		else{
			var div = $('#'+id).closest('div');
			div.removeClass("has-error has-feedback");
			return true;	
		}
	}
	$(document).ready(function(){
		$("#formbtn").click(function(){
			if (!validateText('bukti')) {
				$('#bukti').focus();
				return false;
			}
			return true;
		});
	});
</script>