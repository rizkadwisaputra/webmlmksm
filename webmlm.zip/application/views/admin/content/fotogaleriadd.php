<div class="row">
	<div class="col-md-12">
		<div class="box">
			<div class="box-header">
				<h2 class="box-title">Foto Galeri Add</h2>
			</div>
			<div class="box-body">
				<form method="POST" action="<?php echo base_url('prosesadmin/fotogaleriadd'); ?>" enctype="multipart/form-data">
					<div class="form-group">
						<label>Judul</label>
						<input type="text" id="judul" class="form-control" name="judul" />
					</div>
					<div class="form-group">
						<label>Gambar</label>
						<input type="file" id="gambar" class="form-control" name="gambar" />
					</div>
			</div>
			<div class="box-footer">
				<button type="submit" id="formbtn" class="btn btn-success"><i class="fa fa-save"></i> Simpan</button>
				<a href="<?php echo base_url('admin/fotogaleriview'); ?>" class="btn btn-warning">Cancel</a>
			</div>
				</form>
		</div>
	</div>
</div>
<script>
	function validateText(id){
		if ($('#'+id).val()== null || $('#'+id).val()== "") {
			var div = $('#'+id).closest('div');
			div.addClass("has-error has-feedback");
			return false;
		}
		else{
			var div = $('#'+id).closest('div');
			div.removeClass("has-error has-feedback");
			return true;	
		}
	}
	$(document).ready(function(){
		$("#formbtn").click(function(){
			if (!validateText('judul')) {
				$('#judul').focus();
				return false;
			}
			else if (!validateText('gambar')) {
				$('#gambar').focus();
				return false;
			}
			return true;
		});
	});
</script>