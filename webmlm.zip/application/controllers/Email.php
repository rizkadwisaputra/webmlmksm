<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Email extends CI_Controller {
	public function SendMail(){
		// $ci = get_instance();
  //       $ci->load->library('email');
  //       $config['protocol'] = "smtp";
  //       $config['smtp_host'] = "ssl://smtp.gmail.com";
  //       $config['smtp_port'] = "465";
  //       $config['smtp_timeout'] = '10';
  //       $config['smtp_user'] = "rizka.dwi.saputra2@gmail.com";
  //       $config['smtp_pass'] = "cos2sin3";
  //       $config['charset'] = "utf-8";
  //       $config['mailtype'] = "html";
        
  //       $emailtujuan = $_POST['emailtujuan'];
  //       $subject = "Email Balasan - KSM";
  //       $pesan = $_POST['pesan'];
  //       $ci->email->initialize($config);
  //       $this->email->set_newline("\r\n");
  //       $ci->email->from('rizka.dwi.saputra2@gmail.com', 'Putra - KSM Support');
  //       $list = array($emailtujuan);
  //       $ci->email->to($list);
  //       $ci->email->subject($subject);
  //       $ci->email->message($pesan);
  //       $res = $ci->email->send();
  //       if ($res == true) {
  //          redirect("admin/pesan");
  //       } else {
  //           show_error($this->email->print_debugger());
  //       }
       $name="Putra - KSM Support";
        $email=$_POST['emailtujuan'];
        $subject="Email Balasan - KSM Support";
        $message=$_POST['pesan'];
        $emailku = "info@ksmindo.com";
        $to=$email;

        $headers .= "Reply-To: KSM Support <$emailku>\r\n"; 
        $headers .= "Return-Path: KSM Support <$emailku>\r\n";
        $headers .= "From: KSM Support <$emailku>\r\n";
        $headers .= "Organization: KSM Support\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
        $headers .= "X-Priority: 3\r\n";
        $headers .= "X-Mailer: PHP". phpversion() ."\r\n";
        
        @mail($to,$subject,$message,$headers);
        if(@mail)
        {
            $this->session->set_flashdata('pesan',"<div class='alert alert-success'>Pesan Berhasil Terkirim!</div>");
            redirect("admin/pesanview");  
        }else{
            echo "errorororo";
        }
	}
	public function ProsesPesan(){
		$data_pesan = array(
			"nama"=> $_POST['nama'],
			"email"=> $_POST['email'],
			"subjek"=> $_POST['subjek'],
			"pesan"=> $_POST['isi']
		);
		$res = $this->mod_member->InsertData("pesan",$data_pesan);
		if ($res == true) {
			$this->session->set_flashdata('pesan',"<div class='alert alert-success'>Terimakasih, Pesan Berhasil Terkirim!</div>");
			redirect('page/kontakkami');
		}else{
			"error";
		}
	}
}
