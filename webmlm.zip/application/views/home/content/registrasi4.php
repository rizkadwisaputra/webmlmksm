<div class="container con-1">
	<div class="row">
		<div class="title">
          <h2 class="title-h2"><strong>Registrasi</strong></h2>
          <hr class="styletitle" />
        </div>
	</div>
	<div class="row">
		<div class="col-md-8">
			<h3><center><strong>Registrasi Berhasil</strong></center></h3>
			<br>
			<p>Selamat registrasi berhasil, saat ini sedang dalam proses validasi pembayaran dan jika sukses Admin akan memproses pengaktifan kartu komunitas dan Anda akan mendapatkan sebuah pesan berisikan Username dan Password untuk login ke halaman member komunitas.</p>
			<p>Jika dalam waktu 1x24 jam belum ada notifikasi perihal Akun / Username dan Password Anda silahkan hubungi Admin ke no hp 085669660604.</p>
			
			<hr>
		</div>
		<div class="col-md-4">
			<h3><strong>Panduan</strong></h3>
			<br>
			<div class="alert alert-warning">
				<label>Step 1</label>
				<p>Isi formulir pendaftaran, Bagian Nomor ID didapatkan dari referral Anda atau orang yang mengajak Anda.</p>
			</div>
			<div class="alert alert-warning">
				<label>Step 2</label>
				<p>Lakukan pembayaran ke rekening Admin sesuai dengan nominal yang tertera pada tabel pembayaran.</p>
			</div>
			<div class="alert alert-warning">
				<label>Step 3</label>
				<p>Lakukan konfirmasi pembayaran sesuai dengan nominal yang telah ditentukan, setelah itu Admin akan mengecek pembayaran anda.</p>
			</div>
			<div class="alert alert-info">
				<label>Step 4</label>
				<p>Setelah melakukan konfirmasi pembayaran tunggu beberapa saat, jika dalam waktu 1x24 jam belum ada notifikasi yang dikirim melalui sms, silahkan hubungi admin ke no hp 085669660604.</p>
			</div>
		</div>
	</div>
</div>