<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
	public function __construct(){
		parent::__construct();
		if ($this->session->userdata('idadmin') == "") {
			$this->session->set_flashdata('pesanlogin',"<div class='alert alert-danger'>And harus login!</div>");
			redirect("ksmlogin");
		}
	}
	public function index()
	{
		$content = array(
			"header" => $this->Header(),
			"navigation" => $this->Navigation(),
			"content" => $this->load->view('admin/content/dashboard', array(), true)
		);
		$this->load->view('admin/index.php',$content);
	}
	public function Member()
	{
		$dt_mem = $this->mod_admin->MemberView("where m.status ='bergabung' and m.kd_sponsor !=''")->result_array();
		$content = array(
			"header" => $this->Header(),
			"navigation" => $this->Navigation(),
			"content" => $this->load->view('admin/content/memberview', array('dt_mem'=>$dt_mem), true)
		);
		$this->load->view('admin/index.php',$content);
	}
	public function MemberProses()
	{
		$dt_mem = $this->mod_admin->MemberView("where m.status ='bergabung' and m.kd_sponsor =''")->result_array();
		$content = array(
			"header" => $this->Header(),
			"navigation" => $this->Navigation(),
			"content" => $this->load->view('admin/content/memberproses', array('dt_mem'=>$dt_mem), true)
		);
		$this->load->view('admin/index.php',$content);
	}
	public function MemberBelumTerdaftar()
	{
		$dt_mem = $this->mod_admin->MemberView("where m.status ='belum bergabung' and m.kd_sponsor =''")->result_array();
		$content = array(
			"header" => $this->Header(),
			"navigation" => $this->Navigation(),
			"content" => $this->load->view('admin/content/memberbelumterdaftar', array('dt_mem'=>$dt_mem), true)
		);
		$this->load->view('admin/index.php',$content);
	}
	public function MemberAdd()
	{
		$dt_posisi = $this->mod_admin->PosisiView()->result_array();
		$content = array(
			"header" => $this->Header(),
			"navigation" => $this->Navigation(),
			"content" => $this->load->view('admin/content/memberadd', 
				array('dt_posisi'=>$dt_posisi
					), true)
		);
		$this->load->view('admin/index.php',$content);
	}
	public function MemberEdit($id)
	{
		$dt_posisi = $this->mod_admin->PosisiView()->result_array();
		$dt_mem = $this->mod_admin->MemberView("where m.id_member='$id'")->row_array();
		$content = array(
			"header" => $this->Header(),
			"navigation" => $this->Navigation(),
			"content" => $this->load->view('admin/content/memberedit', 
				array('dt_posisi'=>$dt_posisi, 
						'dt_mem'=>$dt_mem
					), true)
		);
		$this->load->view('admin/index.php',$content);
	}
	public function MemberEditProses($id)
	{
		$dt_posisi = $this->mod_admin->PosisiView()->result_array();
		$dt_mem = $this->mod_admin->MemberView("where m.id_member='$id'")->row_array();
		$content = array(
			"header" => $this->Header(),
			"navigation" => $this->Navigation(),
			"content" => $this->load->view('admin/content/membereditproses', 
				array('dt_posisi'=>$dt_posisi, 
						'dt_mem'=>$dt_mem
					), true)
		);
		$this->load->view('admin/index.php',$content);
	}
	public function KonfirmasiPembayaranView()
	{
		$dt_mem = $this->mod_admin->MemberBelumLunasView("where pp.status='proses'")->result_array();
		$content = array(
			"header" => $this->Header(),
			"navigation" => $this->Navigation(),
			"content" => $this->load->view('admin/content/konfirmasipembayaranview', 
				array('dt_mem'=>$dt_mem
					), true)
		);
		$this->load->view('admin/index.php',$content);
	}
	public function KonfirmasiPembayaranAuto()
	{
		$dt_mem = $this->mod_admin->MemberBelumLunasView("where pp.status='proses' and pp.id_pembayaran_pendaftaran in(select id_pembayaran_pendaftaran from konfirmasi_pem_pendaftaran)")->result_array();
		$content = array(
			"header" => $this->Header(),
			"navigation" => $this->Navigation(),
			"content" => $this->load->view('admin/content/konfirmasipembayaranauto', 
				array('dt_mem'=>$dt_mem
					), true)
		);
		$this->load->view('admin/index.php',$content);
	}
	public function KonfirmasiPembayaranAutoAdd($idmem,$idpem)
	{
		$dt_pem = $this->mod_admin->PembayaranView("where id_pembayaran_pendaftaran='$idpem'")->row_array();
		$dt_kon = $this->mod_admin->KonfirmasiPembayaranView("where pem.id_pembayaran_pendaftaran='$idpem'")->row_array();
		//ambil refferal
		$idref = $dt_pem['id_referral'];
		$dt_ref = $this->mod_admin->ReferralView("where id_referral='$idref'")->row_array();
		$kdsponsor = $dt_ref['kd_sponsor'];
		$dt_sponsor = $this->mod_admin->MemberView("where m.kd_sponsor='$kdsponsor'")->row_array();
		$content = array(
			"header" => $this->Header(),
			"navigation" => $this->Navigation(),
			"content" => $this->load->view('admin/content/konfirmasipembayaranautoadd', 
				array('idmem'=>$idmem,
					'idpem'=>$idpem,
					'dt_pem'=>$dt_pem,
					'dt_kon'=>$dt_kon,
					'dt_sponsor'=>$dt_sponsor
					), true)
		);
		$this->load->view('admin/index.php',$content);
	}
	public function KonfirmasiPembayaran($idmem,$idpem)
	{
		$dt_pem = $this->mod_admin->PembayaranView("where id_pembayaran_pendaftaran='$idpem'")->row_array();
		$dt_mem = $this->mod_admin->MemberView("where m.id_member ='$idmem'")->row_array();
		$content = array(
			"header" => $this->Header(),
			"navigation" => $this->Navigation(),
			"content" => $this->load->view('admin/content/konfirmasipembayaran', 
				array('idmem'=>$idmem,
					'idpem'=>$idpem,
					'dt_pem'=>$dt_pem,
					'dt_mem'=>$dt_mem
					), true)
		);
		$this->load->view('admin/index.php',$content);
	}
	public function MemberDetail($id){
		$dt = $this->mod_admin->MemberDetailView("where m.id_member ='$id'")->row_array();
		//ambil refferal
		$idref = $dt['id_referral'];
		if ($idref == 0) {
			$dt_sponsor = "";
		}else{
			$dt_ref = $this->mod_admin->ReferralView("where id_referral='$idref'")->row_array();
			$kdsponsor = $dt_ref['kd_sponsor'];
			$dt_sponsor = $this->mod_admin->MemberView("where m.kd_sponsor='$kdsponsor'")->row_array();	
		}
		
		$content = array(
			"header" => $this->Header(),
			"navigation" => $this->Navigation(),
			"content" => $this->load->view('admin/content/memberdetail', 
				array('dt'=>$dt,
						'dt_sponsor'=>$dt_sponsor
					), true)
		);
		$this->load->view('admin/index.php',$content);	
	}
	public function MemberDetail2($id){
		$dt = $this->mod_admin->MemberView("where m.id_member ='$id'")->row_array();
		//ambil refferal
		$idref = $dt['id_referral'];
		$dt_ref = $this->mod_admin->ReferralView("where id_referral='$idref'")->row_array();
		$kdsponsor = $dt_ref['kd_sponsor'];
		$dt_sponsor = $this->mod_admin->MemberView("where m.kd_sponsor='$kdsponsor'")->row_array();
		$content = array(
			"header" => $this->Header(),
			"navigation" => $this->Navigation(),
			"content" => $this->load->view('admin/content/memberdetail2', 
				array('dt'=>$dt,
						'dt_sponsor'=>$dt_sponsor
					), true)
		);
		$this->load->view('admin/index.php',$content);	
	}
	//page

	public function PageView(){
		$dt = $this->mod_admin->PageView()->result_array();
		$content = array(
			"header" => $this->Header(),
			"navigation" => $this->Navigation(),
			"content" => $this->load->view('admin/content/pageview', array('dt'=>$dt), true)
		);
		$this->load->view('admin/index.php',$content);	
	}
	public function PageEdit($id){
		$dt = $this->mod_admin->PageView("where id_page = '$id'")->row_array();
		$content = array(
			"header" => $this->Header(),
			"navigation" => $this->Navigation(),
			"content" => $this->load->view('admin/content/pageedit', array('data'=>$dt,'idpage'=>$id), true)
		);
		$this->load->view('admin/index.php',$content);	
	}
	//informasi
	public function InformasiView(){
		$dt = $this->mod_admin->InformasiView()->result_array();
		$content = array(
			"header" => $this->Header(),
			"navigation" => $this->Navigation(),
			"content" => $this->load->view('admin/content/informasiview', array('dt'=>$dt), true)
		);
		$this->load->view('admin/index.php',$content);	
	}
	public function InformasiAdd(){
		$content = array(
			"header" => $this->Header(),
			"navigation" => $this->Navigation(),
			"content" => $this->load->view('admin/content/informasiadd', array(), true)
		);
		$this->load->view('admin/index.php',$content);	
	}
	public function InformasiEdit($id){
		$dt = $this->mod_admin->InformasiView("where id_informasi='$id'")->row_array();
		$content = array(
			"header" => $this->Header(),
			"navigation" => $this->Navigation(),
			"content" => $this->load->view('admin/content/informasiedit', array('data'=>$dt), true)
		);
		$this->load->view('admin/index.php',$content);	
	}
	//presentasi
	public function PresentasiView(){
		$dt = $this->mod_admin->PresentasiView()->result_array();
		$content = array(
			"header" => $this->Header(),
			"navigation" => $this->Navigation(),
			"content" => $this->load->view('admin/content/presentasiview', array('dt'=>$dt), true)
		);
		$this->load->view('admin/index.php',$content);	
	}
	public function PresentasiAdd(){
		$content = array(
			"header" => $this->Header(),
			"navigation" => $this->Navigation(),
			"content" => $this->load->view('admin/content/presentasiadd', array(), true)
		);
		$this->load->view('admin/index.php',$content);	
	}
	public function PresentasiEdit($id){
		$dt = $this->mod_admin->PresentasiView("where id_presentasi='$id'")->row_array();
		$content = array(
			"header" => $this->Header(),
			"navigation" => $this->Navigation(),
			"content" => $this->load->view('admin/content/presentasiedit', array('data'=>$dt), true)
		);
		$this->load->view('admin/index.php',$content);	
	}
	public function FotoGaleriView(){
		$dt = $this->mod_admin->FotoGaleriView()->result_array();
		$content = array(
			"header" => $this->Header(),
			"navigation" => $this->Navigation(),
			"content" => $this->load->view('admin/content/fotogaleriview', array('dt'=>$dt), true)
		);
		$this->load->view('admin/index.php',$content);	
	}
	public function FotoGaleriAdd(){
		$content = array(
			"header" => $this->Header(),
			"navigation" => $this->Navigation(),
			"content" => $this->load->view('admin/content/fotogaleriadd', array(), true)
		);
		$this->load->view('admin/index.php',$content);	
	}
	public function PesanView(){
		$dt = $this->mod_admin->PesanView()->result_array();
		$content = array(
			"header" => $this->Header(),
			"navigation" => $this->Navigation(),
			"content" => $this->load->view('admin/content/pesanview', array('dt'=>$dt), true)
		);
		$this->load->view('admin/index.php',$content);	
	}
	public function BalasPesan($id){
		$dt = $this->mod_admin->PesanView("where id_pesan ='$id'")->row_array();
		$content = array(
			"header" => $this->Header(),
			"navigation" => $this->Navigation(),
			"content" => $this->load->view('admin/content/balaspesan', array('dt'=>$dt), true)
		);
		$this->load->view('admin/index.php',$content);	
	}
	//member view opsi
	public function MemberViewOpsi($res = ""){
		if ($res == "view") {
			$id_posisi = $_POST['opsi'];
		}else{
			$id_posisi = "";
		}
		
		$dt_mem = $this->mod_admin->MemberView("where m.status ='bergabung' and m.kd_sponsor !='' and m.id_posisi='$id_posisi'")->result_array();
		$dt_pos = $this->mod_admin->PosisiView()->result_array();
		$jum = 0;
		$content = array(
			"header" => $this->Header(),
			"navigation" => $this->Navigation(),
			"content" => $this->load->view('admin/content/memberviewopsi', array("jum"=>$jum,"dt_mem"=>$dt_mem,"dt_pos"=>$dt_pos), true)
		);
		$this->load->view('admin/index.php',$content);
	}
	public function DeletePermanen(){
		$content = array(
			"header" => $this->Header(),
			"navigation" => $this->Navigation(),
			"content" => $this->load->view('admin/content/deletepermanen', array(), true)
		);
		$this->load->view('admin/index.php',$content);	
	}	
	private function Navigation(){

		$notif = $this->mod_admin->MemberBelumLunasView("where pp.status='proses' and pp.id_pembayaran_pendaftaran in(select id_pembayaran_pendaftaran from konfirmasi_pem_pendaftaran)")->num_rows();
		$notif2 = $this->mod_admin->MemberView("where m.status ='belum bergabung' and m.kd_sponsor =''")->num_rows();
		$notifpesan = $this->mod_admin->PesanView()->num_rows();
		return $this->load->view('admin/navigation', array('notif'=>$notif,'notif2'=>$notif2, 'notifpesan'=>$notifpesan), true);
	}
	private function Header(){
		return $this->load->view('admin/header', array(), true);
	}
}
