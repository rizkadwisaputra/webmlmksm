<div class="row">
	<div class="title">
      	<h2 class="title-h2"><strong><?php echo $data['judul_informasi']; ?></strong></h2>
        <hr class="styletitle" />
    </div>
</div>
<div class="row">
  <div class="col-md-12 col-sm-12">
    <center><img src="<?php echo base_url("assets/inf-gambar"); ?>/<?php echo $data['gambar']; ?>" style="width:60%;"></center>
    <hr/>
    <?php echo $data['isi']; ?>
  </div>
</div>