<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Member extends CI_Controller {
	public function __construct(){
	 	parent::__construct();
	 	$idmem = $this->session->userdata("idmember");
	 	if ($idmem == "") {
	 		$this->session->set_flashdata('pesanlogin',"<div class='alert alert-danger'>And harus login!</div>");
	 		redirect("mlogin");
	 	}
	 	if ($this->mod_admin->CekKodeSponsor($idmem)== false) {
	 		date_default_timezone_set("Asia/Jakarta");
			//ambil kolom 
			$dt_kol = $this->mod_admin->KolomView("where id_member='$idmem'")->row_array();
			$idkol = $dt_kol['id_kolom'];
			//ambil detail kolom
			$dt_dtkol = $this->mod_admin->DetailKolomView("join konfirmasi_kolom kk ON dk.id_detail_kolom=kk.id_detail_kolom
			 where dk.id_kolom='$idkol' and kk.status_konfirmasi ='proses'")->result_array();
			foreach ($dt_dtkol as $key => $data) {
				if (date("Y-m-d") > $data['tgl_konfirmasi']) {
					$id_dk = $data['id_detail_kolom'];
					$id_kon = $data['id_konfirmasi_kolom'];
					$data_up = array(
						"status_donasi"=>"lunas"
					);
					$this->mod_member->UpdateData("detail_kolom",$data_up,"id_detail_kolom=$id_dk");
					$data_kon = array(
						"status_konfirmasi"=>"lunas"
					);
					$this->mod_member->UpdateData("konfirmasi_kolom",$data_kon,"id_konfirmasi_kolom=$id_kon");
				}
			}
			//cek dan buat kode sponsor
			$dt2 = $this->mod_admin->DetailKolomView("where dk.id_kolom ='$idkol' and k.id_member='$idmem' and dk.status_donasi='lunas'");
			$notif2 = $dt2->num_rows();
			if ($notif2 == 5) {
				$data_kol = array(
					"status_kolom"=>"selesai"
				);
				$this->mod_member->UpdateData("kolom",$data_kol,"id_kolom=$idkol");
				$this->mod_admin->BuatKodeSponsor($idmem);
				redirect("member/donasi");
			}
	 	}
	}
	public function index()
	{
		$idmem = $this->session->userdata("idmember");
		$dt_mem = $this->mod_member->MemberView("where m.id_member='$idmem'")->row_array();
		$kdsponsor = $dt_mem['kd_sponsor'];
		$dt = $this->mod_member->KonfirmasiDonasiView("where dk.kd_sponsor='$kdsponsor' AND dk.status_donasi ='proses'");
		$notif = $dt->num_rows();
		$content = array(
			"header" => $this->Header(),
			"navigation" => $this->Navigation(),
			"content" => $this->load->view('member/content/dashboard', array('kdsponsor'=>$kdsponsor,'idmem'=>$idmem,'notif'=>$notif, 'dt_mem'=>$dt_mem), true)
		);
		$this->load->view('member/index.php',$content);
	}
	public function Profile(){
		$idmem = $this->session->userdata("idmember");
		$dt = $this->mod_member->MemberView("where m.id_member= '$idmem'")->row_array();
		$dt_akun = $this->mod_member->AkunView("where id_member='$idmem'")->row_array();
		//ambil refferal
		$idref = $dt['id_referral'];
		if ($idref == 0) {
			$dt_sponsor = "";
		}else{
			$dt_ref = $this->mod_admin->ReferralView("where id_referral='$idref'")->row_array();
			$kdsponsor = $dt_ref['kd_sponsor'];
			$dt_sp = $this->mod_admin->MemberView("where m.kd_sponsor='$kdsponsor'")->row_array();	
		}
		$content = array(
			"header" => $this->Header(),
			"navigation" => $this->Navigation(),
			"content" => $this->load->view('member/content/profile', array('dt'=>$dt,'dt_akun'=>$dt_akun,'dt_sp'=>$dt_sp), true)
		);
		$this->load->view('member/index.php',$content);
	}
	public function UbahPasswordUser(){
		$idmem = $this->session->userdata("idmember");
		$dt = $this->mod_member->AkunView("where id_member= '$idmem'")->row_array();
		$content = array(
			"header" => $this->Header(),
			"navigation" => $this->Navigation(),
			"content" => $this->load->view('member/content/ubahuserpassword', array('dt'=>$dt), true)
		);
		$this->load->view('member/index.php',$content);	
	}
	public function Donasi()
	{
		$idmem = $this->session->userdata("idmember");
		//ambil kolom 
		$dt_kol = $this->mod_admin->KolomView("where id_member='$idmem'")->row_array();
		$idkol = $dt_kol['id_kolom'];
		$dt = $this->mod_admin->DetailKolomView("where dk.id_kolom ='$idkol' and k.id_member='$idmem' order by dk.id_detail_kolom desc");
		$dt2 = $this->mod_admin->KolomView("where id_kolom ='$idkol' and id_member='$idmem' and status_kolom='proses'");
		$dt_dk = $dt->result_array();
		$jum = $dt2->num_rows();
		$dt_mem = $this->mod_member->MemberView("where m.id_member='$idmem'")->row_array();
		$kdsponsor = $dt_mem['kd_sponsor'];
		$content = array(
			"header" => $this->Header(),
			"navigation" => $this->Navigation(),
			"content" => $this->load->view('member/content/donasi', array("dt_dk"=>$dt_dk,"jum"=>$jum,"kdsponsor"=>$kdsponsor), true)
		);
		$this->load->view('member/index.php',$content);
	}
	public function KonfirmasiDonasi(){
		$kd_sponsor = $this->session->userdata("kdsponsor");
		$dt = $this->mod_member->KonfirmasiDonasiView("where dk.kd_sponsor='$kd_sponsor' AND dk.status_donasi ='proses' group by kk.id_detail_kolom");
		$dt_dk = $dt->result_array();
		$content = array(
			"header" => $this->Header(),
			"navigation" => $this->Navigation(),
			"content" => $this->load->view('member/content/konfirmasidonasiview', array("dt_dk"=>$dt_dk), true)
		);
		$this->load->view('member/index.php',$content);	
	}
	public function KonfirmasiDonasiAdd($id_dk){
		$content = array(
			"header" => $this->Header(),
			"navigation" => $this->Navigation(),
			"content" => $this->load->view('member/content/konfirmasidonasi', array('id_dk'=>$id_dk), true)
		);
		$this->load->view('member/index.php',$content);		
	}
	public function Jaringan(){
		$kd_sponsor = $this->session->userdata("kdsponsor");
		$dt = $this->mod_member->JaringanView("where r.kd_sponsor='$kd_sponsor' AND m.kd_sponsor !=''");
		$dt_jar = $dt->result_array();
		$content = array(
			"header" => $this->Header(),
			"navigation" => $this->Navigation(),
			"content" => $this->load->view('member/content/jaringanview', array("dt_jar"=>$dt_jar), true)
		);
		$this->load->view('member/index.php',$content);	
	}
	public function DetailJaringan($id){
		$dt = $this->mod_member->MemberView("where m.id_member='$id'")->row_array();
		
		$content = array(
			"header" => $this->Header(),
			"navigation" => $this->Navigation(),
			"content" => $this->load->view('member/content/detailjaringan', array("dt"=>$dt), true)
		);
		$this->load->view('member/index.php',$content);	
	}
	private function Navigation(){
		$kd_sponsor = $this->session->userdata("kdsponsor");
		$dt = $this->mod_member->KonfirmasiDonasiView("where dk.kd_sponsor='$kd_sponsor' AND dk.status_donasi ='proses'");
		$notif = $dt->num_rows();
		$idmem = $this->session->userdata("idmember");
		//ambil kolom 
		$dt_kol = $this->mod_admin->KolomView("where id_member='$idmem'")->row_array();
		$idkol = $dt_kol['id_kolom'];
		$dt2 = $this->mod_admin->KolomView("where id_kolom ='$idkol' and id_member='$idmem' and status_kolom='proses'");
		$notif2 = $dt2->num_rows();
		return $this->load->view('member/navigation', array("notif"=>$notif,"notif2"=>$notif2), true);
	}
	private function Header(){
		return $this->load->view('member/header', array(), true);
	}
}
?>