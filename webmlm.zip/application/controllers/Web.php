<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Web extends CI_Controller {

	public function index()
	{
		//presentasi
		$dt_pre = $this->mod_admin->PresentasiView()->result_array("order by id_presentasi desc limit 6");
		//info
		$dt_info = $this->mod_admin->InformasiView()->result_array("order by id_informasi desc limit 6");
		//galeri
		$dt_gal = $this->mod_admin->FotoGaleriView()->result_array("order by id_foto_galeri desc limit 6");
		$content = array(
			"header" => $this->Header(),
			"navigasi" => $this->Navigation(),
			"footer" => $this->Footer(),
			"content" => $this->load->view('home/content/home', array('dt_pre'=>$dt_pre,'dt_info'=>$dt_info,'dt_gal'=>$dt_gal), true)
		);
		$this->load->view('home/web.php',$content);
	}
	private function Navigation(){
		return $this->load->view('home/navigasi', array(), true);
	}
	private function Header(){
		return $this->load->view('home/header', array(), true);
	}
	private function Footer(){
		return $this->load->view('home/footer', array(), true);
	}
}
