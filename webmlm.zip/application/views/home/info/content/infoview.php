<div class="row">
	<div class="title">
      	<h2 class="title-h2"><strong>Informasi</strong></h2>
        <hr class="styletitle" />
    </div>
</div>
<?php foreach ($dt as $key => $data) { ?>
<div class="row info-content">
    <div class="col-md-3 col-sm-12 thumbnail">
    <img src="<?php echo base_url("assets/inf-gambar"); ?>/<?php echo $data['gambar']; ?>" style="width: 300px; height:200px;">
	</div>
	<div class="col-md-8 col-sm-12">
      <h3 style="margin-top:3px;"><a href="<?php echo base_url("info/view"); ?>/<?php echo $data['id_informasi']; ?>/<?php echo $data['slug_url']; ?>"><strong><?php echo $data['judul_informasi']; ?></strong></a></h3>
      <p><?php echo substr(strip_tags($data['isi']), 0,280); ?>....</p>
    </div>
</div>
<hr/>
<?php } ?>