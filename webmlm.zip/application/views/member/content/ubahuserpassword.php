<div class="row">
	<div class="col-md-12 col-sm-12">
		<div class="box">
			<div class="box-header">
				<h2 class="box-title">Ubah Username & Password</h2>
			</div>
			<div class="box-body">
			<?php echo $this->session->flashdata("pesan"); ?>
				<form method="post" action="<?php echo base_url('prosesmember/ubahpassworduser'); ?>">
					<div class="form-group">
						<label>Username</label>
						<input type="text" id="username" class="form-control" value="<?php echo $dt['username']; ?>" name="username" />
						<div id="showresult"></div>
					</div>
					<div class="form-group">
						<label>Password</label>
						<input type="text" id="password" value="<?php echo $dt['password']; ?>" class="form-control" name="password" />
					</div>
			</div>
			<div class="box-footer">
				<button type="submit" class="btn btn-success" id="formbtn"><i class="fa fa-save"></i> Simpan</button>
				<a href="<?php echo base_url('member/profile'); ?>" class="btn btn-warning">Cancel</a>
				</form>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	$(document).ready(function(){
		$('#username').blur(function(){
			var username = $(this).val();
			if (username == "") {
				$('#showresult').hide(300);
				$('#showresult').html("");
			}
			else{
				$.ajax({
					url: "<?php echo base_url('cek/username'); ?>/"+username
				}).done(function(data){
					$('#showresult').html(data);
					$('#showresult').show(300);
				});
			}
		});
	});
</script>
<script>
	function validateText(id){
		if ($('#'+id).val()== null || $('#'+id).val()== "") {
			var div = $('#'+id).closest('div');
			div.addClass("has-error has-feedback");
			return false;
		}
		else{
			var div = $('#'+id).closest('div');
			div.removeClass("has-error has-feedback");
			return true;	
		}
	}
	$(document).ready(function(){
		$("#formbtn").click(function(){
			
			if (!validateText('username')) {
				$('#username').focus();
				return false;
			}
			else if (!validateText('password')) {
				$('#password').focus();
				return false;
			}
			return true;
		});
	});
</script>