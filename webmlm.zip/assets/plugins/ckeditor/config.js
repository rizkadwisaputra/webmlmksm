/**
 * @license Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */

CKEDITOR.editorConfig = function( config ) {
	
	config.filebrowserBrowseUrl = '../assets/plugins/kcfinder/browse.php?type=files';
	config.filebrowserImageBrowseUrl = '../assets/plugins/kcfinder/browse.php?type=images';
	config.filebrowserFlashBrowseUrl = '../../assets/plugins/kcfinder/browse.php?type=flash';
	config.filebrowserUploadUrl = '../../assets/plugins/kcfinder/upload.php?type=files';
	config.filebrowserImageUploadUrl = '../../assets/plugins/kcfinder/upload.php?type=images';
	config.filebrowserFlashUploadUrl = '../../assets/plugins/kcfinder/upload.php?type=flash';
};
