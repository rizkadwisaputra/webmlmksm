<div class="row">
	<div class="col-md-12">
		<div class="box">
			<div class="box-header">
				<h2 class="box-title">Balas Pesan</h2>
			</div>
			<div class="box-body">
				<div class="form-group">
					<label>Isi Pesan</label>
					<textarea class="form-control" rows="5" readonly="true"><?php echo $dt['pesan']; ?></textarea>
				</div>
				<form method="POST" action="<?php echo base_url('email/sendMail'); ?>" enctype="multipart/form-data" >
					<div class="form-group">
						<label>Pesan</label>
						<textarea class="form-control ckeditor" id="pesan" name="pesan"></textarea>
					</div>
					<input type="hidden" name="emailtujuan" value="<?php echo $dt['email']; ?>">
			</div>
			<div class="box-footer">
				<button type="submit" id="formbtn" class="btn btn-success"><i class="fa fa-send"></i> Kirim</button>
				<a href="<?php echo base_url('admin/pesanview'); ?>" class="btn btn-warning">Cancel</a>
			</div>
				</form>
		</div>
	</div>
</div>
