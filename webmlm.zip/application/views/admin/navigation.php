<aside class="main-sidebar">

        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- Sidebar Menu -->
          <ul class="sidebar-menu">
            <li class="header">SYSTEM NAVIGATION</li>
            <!-- Optionally, you can add icons to the links -->
            <li><a href="<?php echo base_url('admin'); ?>"><i class="fa fa-link"></i> <span>Dashboard</span></a></li>
            <li>
              <a href="<?php echo base_url('admin/konfirmasipembayaranauto'); ?>"><i class="fa fa-link"></i> 
                <span>Konfirmasi Pendaftaran</span>
                <?php if ($notif!=0): ?>
                <small class="label pull-right bg-red"><?php echo $notif; ?></small>  
                <?php endif ?>
                
              </a>
            </li>
            <li class="treeview">
              <a href="#"><i class="fa fa-link"></i> <span>Member</span> <i class="fa fa-angle-left pull-right"></i></a>
              <ul class="treeview-menu">
                <li><a href="<?php echo base_url('admin/member'); ?>"><i class="fa fa-eye"></i>Member Terdaftar</a></li>
                <li><a href="<?php echo base_url('admin/memberproses'); ?>"><i class="fa fa-eye"></i>Member Proses</a></li>
                <li><a href="<?php echo base_url('admin/memberbelumterdaftar'); ?>"><i class="fa fa-eye"></i>Member Belum Terdaftar
                  <?php if ($notif2!=0): ?>
                    <small class="label pull-right bg-red"><?php echo $notif2; ?></small>  
                  <?php endif ?>
                </a></li>
                <li><a href="<?php echo base_url('admin/memberadd'); ?>"><i class="fa fa-plus"></i> Tambah Member</a></li>
                <hr style="margin-top:7px; margin-bottom:5px;" />
                <li><a href="<?php echo base_url('admin/memberviewopsi'); ?>"><i class="fa fa-link"></i> <span>View Opsi</span></a></li>
              </ul>
            </li>
            <li class="treeview">
              <a href="#"><i class="fa fa-link"></i> <span>Pembayaran Manual</span> <i class="fa fa-angle-left pull-right"></i></a>
              <ul class="treeview-menu">
                <li><a href="<?php echo base_url('admin/konfirmasipembayaranview'); ?>">Konfirmasi Pembayaran Manual</a></li>
              </ul>
            </li>
            <li>
              <a href="<?php echo base_url('admin/pesanview'); ?>"><i class="fa fa-link"></i> 
                <span>Pesan</span>
                <?php if ($notifpesan!=0): ?>
                <small class="label pull-right bg-red"><?php echo $notifpesan; ?></small>  
                <?php endif ?>
                
              </a>
            </li><li>
              <a href="<?php echo base_url('admin/deletepermanen'); ?>"><i class="fa fa-link"></i> 
                <span>Delete Member</span>
              </a>
            </li>

            <li class="header">WEB NAVIGATION</li>
            <li><a href="<?php echo base_url('admin/pageview'); ?>"><i class="fa fa-link"></i> <span>Page</span></a></li>
            <li><a href="<?php echo base_url('admin/informasiview'); ?>"><i class="fa fa-link"></i> <span>Informasi</span></a></li>
            <li><a href="<?php echo base_url('admin/presentasiview'); ?>"><i class="fa fa-link"></i> <span>Presentasi</span></a></li>
            <li><a href="<?php echo base_url('admin/fotogaleriview'); ?>"><i class="fa fa-link"></i> <span>Foto Galeri</span></a></li>
          </ul><!-- /.sidebar-menu -->
        </section>
        <!-- /.sidebar -->
      </aside>