<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Kontak Kami | KSM</title>
    <meta name="description" content="KSM adalah Komunitas Saling Membantu untuk menyejahterakan rakyat terutama para petani dengan memberikan pelatihan pupuk organik jamu bumi">
    <meta name="keywords" content="ksm, komunitas saling membantu, jamu bumi, pupuk organik, kms pupuk organik, ksm indonesia">
    <link rel="icon" type="image/png" href="<?php echo base_url('assets/logo/logo.png'); ?>">
    <!-- Bootstrap -->
    <link href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css'); ?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/dist/css/costumweb.css'); ?>" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/owl/css/owl.carousel.css" rel="stylesheet">  
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="<?php echo base_url('assets/plugins/jQuery/jQuery.min.js'); ?>"></script>
  </head>
  <body>
    <div class="top-nav"></div>
    <?php echo $navigasi; ?>
<div class="container con-1">
	<div class="row">
		<div class="title">
          <h2 class="title-h2"><strong>Kontak Kami</strong></h2>
          <hr class="styletitle" />
        </div>
	</div>
	<div class="row">
		<div class="col-md-5 col-sm-12">
			<table class="table">
        <tr>
          <td width="20%">Alamat</td>
          <td width="1%">:</td>
          <td>Jl. Soekarno Hatta, No 16 Mulyojati 16c, Metro Barat, Lampung</td>
        </tr>
        <tr>
          <td width="20%">No Hp</td>
          <td width="1%">:</td>
          <td>081369506139</td>
        </tr>
        <tr>
          <td width="20%">Email</td>
          <td width="1%">:</td>
          <td>info@ksmindo.com</td>
        </tr>
      </table>
		</div>
    <div class="col-md-7 col-sm-12">
    <?php echo $this->session->flashdata("pesan"); ?>
    <form method="post" action="<?php echo base_url('email/prosespesan'); ?>">
      <div class="col-md-12 col-sm-12">
        <div class="form-group">
          <input type="text" class="form-control" id="nama" name="nama" placeholder="Masukan Nama Anda">
        </div>
      </div>
      <div class="col-md-6 col-sm-6">
        <div class="form-group">
          <input type="email" class="form-control" id="email" name="email" placeholder="Masukan Email Anda">
        </div>
      </div>
      <div class="col-md-6 col-sm-6">
        <div class="form-group">
          <input type="text" class="form-control" id="subjek" name="subjek" placeholder="Masukan Subjek Pesan">
        </div>
      </div>
      <div class="col-md-12 col-sm-12">
        <div class="form-group">
          <textarea class="form-control" id="isi" name="isi" rows="6"></textarea>
        </div>
      </div>
      <div class="col-md-12 col-sm-12">
        <button type="submit" id="formbtn" class="btn btn-success">Kirim Pesan</button>
      </div>
    </form>
    </div>
	</div>
</div>
    <footer class="footer">
      <div class="container">
        <p class="text-footer">Copyright &copy; 2016 <a href="">KSM (Komunitas Saling Membantu)</a></p>
      </div>
    </footer>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js'); ?>"></script>
  </body>
  <script>
  function validateText(id){
    if ($('#'+id).val()== null || $('#'+id).val()== "") {
      var div = $('#'+id).closest('div');
      div.addClass("has-error has-feedback");
      return false;
    }
    else{
      var div = $('#'+id).closest('div');
      div.removeClass("has-error has-feedback");
      return true;  
    }
  }
  $(document).ready(function(){
    $("#formbtn").click(function(){
      if (!validateText('nama')) {
        $('#nama').focus();
        return false;
      }
      else if (!validateText('email')) {
        $('#email').focus();
        return false;
      }
      else if (!validateText('subjek')) {
        $('#subjek').focus();
        return false;
      }
      else if (!validateText('isi')) {
        $('#isi').focus();
        return false;
      }
      return true;
    });
  });
</script>
</html>