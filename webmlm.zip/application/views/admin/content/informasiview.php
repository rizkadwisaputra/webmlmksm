<div class="row">
	<div class="col-md-12 col-sm-12">
		<div class="box">
			<div class="box-header">
				<h2 class="box-title">Informasi View</h2>
			</div>
			<div class="box-body">
				<table id="tableku" class="table table-hover">
					<thead>
						<tr>
							<th>No</th>
							<th>Judul</th>
							<th>Gambar</th>
							<th>Tgl</th>
							<th>Slug Url</th>
							<th>Aksi</th>
						</tr>
					</thead>
					<tbody>
					<?php  foreach ($dt as $key => $data) { ?>
						<tr>
							<td><?php echo $key+1; ?></td>
							<td><?php echo $data['judul_informasi']; ?></td>
							<td>
							<img src="<?php echo base_url("assets/inf-gambar"); ?>/<?php echo $data['gambar']; ?>" class="img-responsive" width="150">
							</td>
							<td><?php echo $data['tgl_informasi']; ?></td>
							<td><?php echo $data['slug_url']; ?></td>
							<td>
								<a href="<?php echo base_url('admin/informasiedit'); ?>/<?php echo $data['id_informasi']; ?>" class="btn btn-success btn-xs"><i class="fa fa-edit"></i> Edit</a>
								<a href="<?php echo base_url('info/view'); ?>/<?php echo $data['id_informasi']; ?>/<?php echo $data['slug_url']; ?>" target="_blank" class="btn btn-primary btn-xs"><i class="fa fa-search"></i> View</a>
								<a href="<?php echo base_url('prosesadmin/informasidelete'); ?>/<?php echo $data['id_informasi']; ?>" class="btn btn-danger btn-xs" onclick="return confirm('Lanjutkan menghapus!');"><i class="fa fa-trash"></i> Hapus</a>
							</td>
						</tr>
					<?php } ?>
					</tbody>
				</table>
			</div>
			<div class="box-footer">
				<a href="<?php echo base_url("admin/informasiadd"); ?>" class="btn btn-info"><i class="fa fa-plus"></i> Tambah Informasi</a>
			</div>
		</div>
	</div>
</div>
