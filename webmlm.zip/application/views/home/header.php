<!DOCTYPE html>
<html lang="en">
  <head>
    <title>KSM | Komunitas Saling Membantu</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="KSM adalah Komunitas Saling Membantu untuk menyejahterakan rakyat terutama para petani dengan memberikan pelatihan pupuk organik jamu bumi">
    <meta name="keywords" content="ksm, komunitas saling membantu, jamu bumi, pupuk organik, kms pupuk organik, ksm indonesia">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    
    <link rel="icon" type="image/png" href="<?php echo base_url('assets/logo/logo.png'); ?>">
    <!-- Bootstrap -->
    <link href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css'); ?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/dist/css/costumweb.css'); ?>" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/plugins/lightbox/css/lightbox.min.css" rel="stylesheet">  
    <link href="<?php echo base_url(); ?>assets/owl/css/owl.carousel.css" rel="stylesheet">  
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="<?php echo base_url('assets/plugins/jQuery/jQuery.min.js'); ?>"></script>
  </head>
  <body>
    <div class="top-nav"></div>