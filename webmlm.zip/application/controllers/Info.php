<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Info extends CI_Controller {

	public function index()
	{
		$data = $this->mod_admin->InformasiView()->result_array();
		$content = array(
			"navigasi" => $this->Navigation(),
			"content"=>$this->load->view("home/info/content/infoview",array("dt"=>$data),true),
			"deskripsi"=>"KSM adalah Komunitas Saling Membantu untuk menyejahterakan rakyat terutama para petani dengan memberikan pelatihan pupuk organik jamu bumi",
			"keywords"=>"ksm, komunitas saling membantu, jamu bumi, pupuk organik, kms pupuk organik, ksm indonesia"
		);
		$this->load->view('home/info/informasi',$content);
	}
	public function View($id="",$slug=""){
		if ($slug != "" && $id != "") {
			$data = $this->mod_admin->InformasiView("where id_informasi='$id'")->row_array();
			if ($data['slug_url'] == $slug && $data['id_informasi']==$id) {
				$content = array(
					"navigasi" => $this->Navigation(),
					"content"=>$this->load->view("home/info/content/infodetail",array("data"=>$data),true),
					"deskripsi"=>$data['deskripsi'],
					"keywords"=>$data['kata_kunci']
				);
				$this->load->view('home/info/informasi',$content);
			}else{
				$this->load->view("errors/404.html");
			}
		}else{
			$this->load->view("errors/404.html");
		}
	}

	private function Navigation(){
		return $this->load->view('home/navigasi', array(), true);
	}
}
