<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class DeleteMember extends CI_Controller {

	public function Set(){
		$kdref = $_POST['noref'];
		$dtmem = $this->mod_admin->MemberView("where m.kd_sponsor='$kdref'")->row_array();
		$cekmem = $this->mod_admin->MemberView("where m.kd_sponsor='$kdref'")->num_rows();
		if ($cekmem == 0) {
			echo "Data Tidak tersedia";
		}
		$idmem = $dtmem['id_member'];
		$idref = $dtmem['id_referral'];
		$dtpem = $this->mod_admin->PembayaranView("where m.id_member='$idmem'")->row_array();
		$idpem = $dtpem['id_pembayaran_pendaftaran'];
		$dtkol = $this->mod_admin->KolomView("where id_member='$idmem'")->row_array();
		$idkol = $dtkol['id_kolom'];
		$dtdkol = $this->mod_admin->DetailKolomView("where dk.id_kolom='$idkol'")->result_array();
		
		//delete konfirmasi pem
		$this->mod_admin->DeleteData("konfirmasi_pem_pendaftaran","id_pembayaran_pendaftaran=$idpem");
		//delete pembayaran pem
		$this->mod_admin->DeleteData("pembayaran_pendaftaran","id_member = $idmem");
		//delete referral
		$this->mod_admin->DeleteData("referral","id_referral = $idref");
		//delete akun
		$this->mod_admin->DeleteData("member_akun","id_member = $idmem");
		//kolom
		//delete detail
		foreach ($dtdkol as $key => $data) {
			$iddkol = $data['id_detail_kolom'];
			$dtkonkol = $this->mod_admin->KonfirmasiKolomView("where kk.id_detail_kolom=$iddkol")->num_rows();
			if ($dtkonkol > 0) {
				$this->mod_admin->DeleteData("konfirmasi_kolom", "id_detail_kolom=$iddkol");
			}
			$this->mod_admin->DeleteData("detail_kolom", "id_detail_kolom=$iddkol");
		}
		//delete kolom
		$this->mod_admin->DeleteData("kolom","id_member=$idmem");
		//fix delete member
		$res = $this->mod_admin->DeleteData("member","id_member=$idmem");
		if ($res==true) {
			echo "<center><br/><h2>Data Berhasil Di hapus</h2></center>";
			echo "<center><a href='http://ksmindo.com/admin'>Back Home</a></center>";
		}
	}
}
