<div class="row">
	<div class="col-md-12">
		<div class="box box-info">
			<div class="box-header">
				<h2 class="box-title">Pilih Opsi Tampil</h2>
			</div>
			<div class="box-body">
				<div class="col-sm-4">
					<form method="post" action="<?php echo base_url('admin/memberviewopsi/view'); ?>">
					<div class="form-group">
						<select id="opsi" name="opsi" class="form-control">
							<option value="">--- Pilih Posisi ---</option>
							<?php foreach ($dt_pos as $key => $data) { ?>
								<option value="<?php echo $data['id_posisi']; ?>"><?php echo $data['nama_posisi']; ?></option>
							<?php } ?>
						</select>
					</div>
					
				</div>
				<div class="col-sm-8">
					<button type="submit" id="opsi" class="btn btn-primary">Proses</button>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>

<?php if ($jum != 1) { ?>
<div class="row">
	<div class="col-md-12 col-sm-12">
		<div class="box">
			<div class="box-header">
				<h2 class="box-title">Data Member</h2>
			</div>
			<div class="box-body">
				<table id="tableku" class="table table-hover">
					<thead>
						<tr>
							<th>No</th>
							<th>Nama</th>
							<th>Nomor ID</th>
							<th>Posisi</th>
							<th>Alamat</th>
							<th>No Hp Ooredoo</th>
							<th>Aksi</th>
						</tr>
					</thead>
					<tbody>
					<?php  foreach ($dt_mem as $key => $data) { ?>
						<tr>
							<td><?php echo $key+1; ?></td>
							<td><?php echo $data['nama_lengkap']; ?></td>
							<td><?php echo $data['kd_sponsor']; ?></td>
							<td><?php echo $data['nama_posisi']; ?></td>
							<td><?php echo $data['alamat']; ?></td>
							<td><?php echo $data['no_hp_oredo']; ?></td>
							<td>
								<a href="<?php echo base_url('admin/memberedit'); ?>/<?php echo $data['id_member']; ?>" class="btn btn-primary btn-xs"><i class="fa fa-edit"></i> Edit</a>
								<a href="<?php echo base_url('admin/memberdetail'); ?>/<?php echo $data['id_member']; ?>" class="btn btn-success btn-xs"><i class="fa fa-search"></i> Detail</a>
							</td>
						</tr>
					<?php } ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<?php } ?>