<div class="row">
	<div class="col-md-12 col-sm-12">
		<?php if ($jum>0){ ?>
		<div class="alert alert-info">
			<p><font size="5">Lakukan donasi kepada anggota KSM yang lain<br/><strong>Transfer <span style="color:green;">Rp. 100.000,-</span> ke No REK yang tertera pada setiap anggota.</strong></font></p>
		</div>
		<div class="alert alert-danger">
			<p><strong>CATATAN :</strong></p>
			<p>Setelah melakukan transfer harap hubungi setiap anggota yang telah anda konfirmasi, sesuai dengan No TELP yang tertera.</p>
			<p>Jika anda sudah melakukan donasi kepada 5 anggota dan jika dalam waktu 1x24 jam anda tidak mendapatkan notifikasi Nomor ID Anda, Harap login untuk pengecekan Nomor ID anda.</p>
		</div>
		<?php }else{ ?>
		<div class="alert alert-success">
			<center><h3>Anda sudah melakukan donasi ke 5 orang.</h3></center>
		</div>
		<?php } ?>
		<div class="box">
			<div class="box-body">
				<?php if ($jum > 0) { ?>
				<div class="table-responsive">
					<table class="table">
						<tbody>
						<?php  
							foreach ($dt_dk as $key => $data) {
								if ($data['status_donasi']=='belum lunas') {
									$clss  = "d-not";
								}else if($data['status_donasi']=='proses'){
									$clss = "d-proses";
								}else{
									$clss = "d-sukses";
								}
						?>
							<tr class="<?php echo $clss; ?>">
								<td width="7%">
									<font size="8"><b><?php echo $data['no']; ?></b></font>
								</td>
								<td>
									<table class="table table-bordered table-hover" style="margin:0px !important;">
										<tr class="info">
											<td width="20%">Nama</td>
											<td><?php echo $data['nama_lengkap']; ?></td>
										</tr>
										<tr class="info">
											<td width="20%">No HP</td>
											<td><?php echo $data['no_hp_oredo']; ?></td>
										</tr>
										<tr  class="info">
											<td width="20%">Nama Bank</td>
											<td><?php echo $data['nama_bank']; ?></td>
										</tr>
										<tr  class="info">
											<td width="20%">No Rek</td>
											<td><?php echo $data['no_rek']; ?></td>
										</tr>
									</table>
								</td>
								<td>
									<?php if ($data['status_donasi']=="belum lunas") {?>
									<a href="<?php echo base_url("member/konfirmasidonasiadd"); ?>/<?php echo $data['id_detail_kolom']; ?>" class="btn btn-primary" onclick="return confirm('Apakah anda yakin ingin mengkonfirmasi pembayaran?');"><i class="fa fa-check"></i> Konfirmasi</a>
									<?php }elseif($data['status_donasi']=="proses"){ ?>
									<button class="btn btn-warning"><i class="fa fa-warning"></i>  Proses</button>
									<?php }else{ ?>
									<button class="btn btn-success"><i class="fa fa-thumbs-up"></i> Sukses</button>
									<?php } ?>
								</td>
							</tr>
						<?php } ?>
						</tbody>
					</table>
				</div>
				<?php }else{ ?>
				<center><h4>Nomor ID Anda</h4></center>
				<center><h1><?php echo $kdsponsor; ?></h1></center>
				<?php } ?>
			</div>
		</div>
	</div>
</div>