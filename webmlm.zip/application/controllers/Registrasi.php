<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Registrasi extends CI_Controller {

	public function index()
	{
		$this->Step1();
	}
	public function Step1(){
		$dt_posisi = $this->mod_admin->PosisiView("order by id_posisi desc limit 4")->result_array();
		$content = array(
			"header" => $this->Header(),
			"navigasi" => $this->Navigation(),
			"footer" => $this->Footer(),
			"content" => $this->load->view('home/content/registrasi', array('dt_posisi'=>$dt_posisi), true)
		);
		return $this->load->view('home/web',$content);		
	}
	public function Step2($id="",$idpem=""){
		$dt_pem = $this->mod_admin->PembayaranView("where pem.id_member='$id'")->row_array();
		$nominal = $dt_pem['nominal_tagihan'];
		$content = array(
			"header" => $this->Header(),
			"navigasi" => $this->Navigation(),
			"footer" => $this->Footer(),
			"content" => $this->load->view('home/content/registrasi2', array('nominal'=>$nominal,'idmem'=>$id,'idpem'=>$idpem), true)
		);
		$this->load->view('home/web',$content);		
	}
	public function Step3($idmem="",$idpem=""){
		$dt_pem = $this->mod_admin->PembayaranView("where id_pembayaran_pendaftaran='$idpem'")->row_array();
		$content = array(
			"header" => $this->Header(),
			"navigasi" => $this->Navigation(),
			"footer" => $this->Footer(),
			"content" => $this->load->view('home/content/registrasi3', array('idmem'=>$idmem,'idpem'=>$idpem,'dt_pem'=>$dt_pem), true)
		);
		$this->load->view('home/web',$content);		
	}
	public function Step4(){
		$content = array(
			"header" => $this->Header(),
			"navigasi" => $this->Navigation(),
			"footer" => $this->Footer(),
			"content" => $this->load->view('home/content/registrasi4', array(), true)
		);
		$this->load->view('home/web.php',$content);		
	}
	private function Navigation(){
		return $this->load->view('home/navigasi', array(), true);
	}
	private function Header(){
		return $this->load->view('home/header', array(), true);
	}
	private function Footer(){
		return $this->load->view('home/footer', array(), true);
	}
}
