<aside class="main-sidebar">

        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- Sidebar Menu -->
          <ul class="sidebar-menu">
            <li class="header">NAVIGATION</li>
            <!-- Optionally, you can add icons to the links -->
            <li><a href="<?php echo base_url('member'); ?>"><i class="fa fa-link"></i> <span>Dashboard</span></a></li>
            <?php if ($notif2 > 0) {?>
            <li class="active">
              <a href="<?php echo base_url('member/donasi'); ?>">
                <i class="fa fa-link"></i> <span>Donasi</span>
                <small class="label pull-right" style="color:red; font-size:15px;"><i class="fa fa-warning"></i></small>  
              </a>
            </li>
            <?php } ?>
            <li>
              <a href="<?php echo base_url('member/konfirmasidonasi'); ?>">
                <i class="fa fa-link"></i> <span>Konfirmasi Donasi</span>
                <?php if ($notif!=0): ?>
                <small class="label pull-right bg-red"><?php echo $notif; ?></small>  
                <?php endif ?>
              </a>
            </li>
            <li><a href="<?php echo base_url('member/profile'); ?>"><i class="fa fa-link"></i> <span>Profile</span></a></li>
            <li><a href="<?php echo base_url('member/jaringan'); ?>"><i class="fa fa-link"></i> <span>Jaringan</span></a></li>
          </ul><!-- /.sidebar-menu -->
        </section>
        <!-- /.sidebar -->
      </aside>