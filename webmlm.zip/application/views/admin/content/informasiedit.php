<div class="row">
	<div class="col-md-12">
		<div class="box">
			<div class="box-header">
				<h2 class="box-title">Informasi Add</h2>
			</div>
			<div class="box-body">
				<form method="POST" action="<?php echo base_url('prosesadmin/informasiedit'); ?>/<?php echo $data['id_informasi']; ?>" enctype="multipart/form-data">
					<div class="form-group">
						<label>Judul</label>
						<input type="text" id="judul" class="form-control" value="<?php echo $data['judul_informasi']; ?>" name="judul" />
					</div>
					<div class="form-group">
						<label>Gambar</label>
						<input type="file" id="gambar" class="form-control" name="gambar" />
						<br/>
						<img src="<?php echo base_url("assets/inf-gambar"); ?>/<?php echo $data['gambar']; ?>" class="img-responsive" width="150">
					</div>
					<div class="form-group">
						<label>ISI</label>
						<textarea class="form-control ckeditor" id="isi" name="isi"><?php echo $data['isi']; ?></textarea>
					</div>
					<hr/>
					<h3>SEO</h3>
					<div class="form-group">
						<label>Deskripsi</label>
						<textarea class="form-control" id="deskripsi" name="deskripsi"><?php echo $data['deskripsi']; ?></textarea>
					</div>
					<div class="form-group">
						<label>Kata Kunci</label>
						<input type="text" name="kata_kunci" id="kata_kunci" class="form-control" value="<?php echo $data['kata_kunci']; ?>"/>
					</div>
					<div class="form-group">
						<label>Slug URL</label>
						<input type="text" name="slug" id="slug" class="form-control" value="<?php echo $data['slug_url']; ?>"/>
					</div>
					<input type="hidden" name="nama_gambar" value="<?php echo $data['gambar']; ?>" />
			</div>
			<div class="box-footer">
				<button type="submit" id="formbtn" class="btn btn-success"><i class="fa fa-save"></i> Simpan</button>
				<a href="<?php echo base_url('admin/informasiview'); ?>" class="btn btn-warning">Cancel</a>
			</div>
				</form>
		</div>
	</div>
</div>
<script>
	function validateText(id){
		if ($('#'+id).val()== null || $('#'+id).val()== "") {
			var div = $('#'+id).closest('div');
			div.addClass("has-error has-feedback");
			return false;
		}
		else{
			var div = $('#'+id).closest('div');
			div.removeClass("has-error has-feedback");
			return true;	
		}
	}
	$(document).ready(function(){
		$("#formbtn").click(function(){
			if (!validateText('judul')) {
				$('#judul').focus();
				return false;
			}
			else if (!validateText('deskripsi')) {
				$('#deskripsi').focus();
				return false;
			}
			else if (!validateText('kata_kunci')) {
				$('#kata_kunci').focus();
				return false;
			}
			else if (!validateText('slug')) {
				$('#slug').focus();
				return false;
			}
			return true;
		});
	});
</script>