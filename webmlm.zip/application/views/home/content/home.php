<div id="img-header"></div>
<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
    <li data-target="#carousel-example-generic" data-slide-to="2"></li>
    <li data-target="#carousel-example-generic" data-slide-to="3"></li>
    <li data-target="#carousel-example-generic" data-slide-to="4"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
      <img src="<?php echo base_url(); ?>assets/img-slider/1.jpg" alt="Komunitas Saling Membantu">
    </div>
    <div class="item">
      <img src="<?php echo base_url(); ?>assets/img-slider/2.jpg" alt="Komunitas Saling Membantu">
    </div>
    <div class="item">
      <img src="<?php echo base_url(); ?>assets/img-slider/3.jpg" alt="Komunitas Saling Membantu">
    </div>
    <div class="item">
      <img src="<?php echo base_url(); ?>assets/img-slider/4.jpg" alt="Komunitas Saling Membantu">
    </div>
    <div class="item">
      <img src="<?php echo base_url(); ?>assets/img-slider/5.jpg" alt="Komunitas Saling Membantu">
    </div>
  </div>
  <!-- Controls -->
  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
<div class="container">
      <br>
      <div class="row con-1">
        <div class="title">
          <h2 class="title-h2">Komunitas Saling Membantu</h2>
          <hr class="styletitle" />
        </div>
      </div>
      <br>
      <div class="row">
        <div class="col-md-10">
          <p>Komunitas Saling Membantu Adalah sebuah komunitas yang ingin merubah paradigma masyarakat indonesia tentang hidup, bahwa hidup untuk memberi bukan menerima, bersama KSM ingin memberdayakan petani indonesia menjadi petani mandiri dan memperbaiki bumi nusantara supaya kembali subur bebas dari pupuk kimia, agar masyarakat indonesia sehat sejahtera.</p>
        </div>
        <div class="col-md-2">
          <center><a href="<?php echo base_url('registrasi'); ?>" class="btn btn-success">DAFTAR</a></center>
        </div>
      </div>
      <br>
</div>
      <hr>
<div class="container">
      <div class="row con-1">
        <div class="title">
          <h2 class="title-h2">Apa yang anda dapatkan?</h2>
          <hr class="styletitle" />
        </div>
      </div>
      <br>
      <div class="row">
        <div class="col-md-12 sol-sm-12">
          <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
            <div class="panel panel-default">
              <div class="panel-heading" role="tab" id="headingOne">
                <h4 class="panel-title">
                  <a role="button" data-toggle="collapse" data-parent="#accordion" href="#list1" aria-expanded="true" aria-controls="collapseOne">
                    Kartu Komunitas Saling Membantu
                  </a>
                </h4>
              </div>
              <div id="list1" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                <div class="panel-body">
                  <p>Kartu KSM(Komunitas Saling Membantu) merupakan sebuah kartu komunitas yang dimiliki oleh KSM.</p>
                  <p>Kartu KSM tercipta atas kerjasama antara Komunitas Saling Membantu dengan PT Artha Rizki Persada yang langsung didukung oleh Indosat Ooredoo.</p>
                  <p>Manfaat dari kartu KSM yaitu memudahkan segala bentuk kebutuhan terutama dalam bidang komunikasi, selain itu ada banyak lagi manfaat bagi KSM dan juga seluruh anggota didalamnya.</p>
                </div>
              </div>
            </div>
            <div class="panel panel-default">
              <div class="panel-heading" role="tab" id="headingTwo">
                <h4 class="panel-title">
                  <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#list2" aria-expanded="false" aria-controls="collapseTwo">
                    Pelatihan Pertanian Organik
                  </a>
                </h4>
              </div>
              <div id="list2" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                <div class="panel-body">
                  <p>Anda akan diajarkan cara membuat pupuk organik dengan kualitas yang baik hanya dengan menggunakan bahan-bahan disekitar Anda dan aggota komunitas juga diajarkan bagaimana cara sukses dalam bidang pertanian khususnya.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <br>
</div>
      <hr>
<div class="container">
      <div class="row con-1">
        <div class="title">
          <h2 class="title-h2">Presentasi</h2>
          <hr class="styletitle" />
        </div>
      </div>
      <br>
      <!-- conten slider dengan owl carousel -->
      <div class="row">
        <div class="col-md-12 col-sm-12">
          <div id="owl" class="owl-carousel owl-theme">
          <?php foreach ($dt_pre as $key => $data) { ?>
            <div class="item foto-g">
              <div class="thumbnail">
                <img src="<?php echo base_url(); ?>assets/pre-gambar/<?php echo $data['gambar']; ?>" alt="<?php echo $data['judul_presentasi']; ?>" style="width: 300px; height:200px;">
              </div>
              <div class="judul-pre">
                <a href="<?php echo base_url('presentasi/view'); ?>/<?php echo $data['id_presentasi']; ?>/<?php echo $data['slug_url']; ?>"><strong><?php echo $data['judul_presentasi']; ?></strong></a>
              </div>
            </div>
            <?php } ?>
          </div>
        </div>
        <div class="col-md-12 col-sm-12">
        <br>
          <center><a href="<?php echo base_url('presentasi'); ?>" class="btn btn-success">Lihat Lainya</a></center>
        </div>
      </div>
      <br>
</div>
      <hr>
<div class="container">
      <div class="row con-1">
        <div class="title">
          <h2 class="title-h2">Foto Galeri</h2>
          <hr class="styletitle" />
        </div>
      </div>
      <br>
      <div class="row">
        <div class="col-md-12 col-sm-12">
          <div id="owl2" class="owl-carousel owl-theme">
            
            <?php foreach ($dt_gal as $key => $data) { ?>
            <div class="item foto-g">
              <a href="<?php echo base_url('assets/foto-galeri'); ?>/<?php echo $data['foto']; ?>" class="thumbnail" data-lightbox="gallery" data-title="<?php echo $data['judul_foto']; ?>">
                <img src="<?php echo base_url(); ?>assets/foto-galeri/<?php echo $data['foto']; ?>" alt="<?php echo $data['judul_foto']; ?>" style="width: 350px; height:200px;">
              </a>
            </div>
            <?php } ?>
          </div>
        </div>
        <div class="col-md-12 col-sm-12">
        <br>
          <center><a href="<?php echo base_url('fotogaleri'); ?>" class="btn btn-success">Lihat Lainya</a></center>
        </div>
      </div>
      <br>
</div>
      <hr>
<div class="container">
      <div class="row con-1">
        <div class="title">
          <h2 class="title-h2">Info & Berita Terbaru</h2>
          <hr class="styletitle" />
        </div>
      </div>
      <br>
      <!-- conten slider dengan owl carousel -->
      <div class="row">
        <div class="col-md-12 col-sm-12">
          <div id="owl3" class="owl-carousel owl-theme">
            <?php foreach ($dt_info as $key => $data) { ?>
            <div class="item foto-g">
              <div class="thumbnail">
                <img src="<?php echo base_url(); ?>assets/inf-gambar/<?php echo $data['gambar']; ?>" alt="<?php echo $data['judul_informasi']; ?>" style="width: 300px; height:200px;">
              </div>
              <div class="judul-pre">
                <a href="<?php echo base_url('info/view'); ?>/<?php echo $data['id_informasi']; ?>/<?php echo $data['slug_url']; ?>"><strong><?php echo $data['judul_informasi']; ?></strong></a>
              </div>
            </div>
            <?php } ?>
          </div>
        </div>
        <div class="col-md-12 col-sm-12">
        <br>
          <center><a href="<?php echo base_url("info"); ?>" class="btn btn-success">Lihat Lainya</a></center>
        </div>
      </div>
    </div>
    <br>