<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Page extends CI_Controller {

	public function index()
	{
		$this->load->view("errors/404.html");
	}
	public function View($slug=""){
		if ($slug != "") {
			$data = $this->mod_admin->pageview("where slug_url='$slug'")->row_array();
			if ($data['slug_url'] ==$slug) {
				$content = array(
					"navigasi" => $this->Navigation(),
					"data"=>$data
				);
				$this->load->view('home/page',$content);
			}else{
				$this->load->view("errors/404.html");
			}
		}else{
			$this->load->view("errors/404.html");
		}
	}
	public function KontakKami(){
		$content = array(
			"navigasi" => $this->Navigation()
		);
		$this->load->view('home/kontakkami',$content);
	}

	private function Navigation(){
		return $this->load->view('home/navigasi', array(), true);
	}
	private function Header(){
		return $this->load->view('home/header', array(), true);
	}
	private function Footer(){
		return $this->load->view('home/footer', array(), true);
	}
}
