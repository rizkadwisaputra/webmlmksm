<div class="row">
	<div class="col-md-12">
		<div class="box">
			<div class="box-header">
				<h2 class="box-title">Tambah Member</h2>
			</div>
			<div class="box-body">
			<?php echo $this->session->flashdata("pesansponsor"); ?>
				<form method="POST" action="<?php echo base_url('prosesadmin/memberadd'); ?>">
					<div class="form-group">
						<label>Nomor ID</label>
						<input type="text" class="form-control" id="sponsor" name="sponsor" />
						<p class="text-warning"><i>  Nomor ID diambil dari referral anda.<i></p>
						<div id="showresult" style="display:none; padding-bottom:0;"></div>
					</div>
					<div class="form-group">
						<label>Nama Lengkap</label>
						<input type="text" id="nama" class="form-control" name="nama" />
					</div>
					<div class="form-group">
						<label>No KTP</label>
						<input type="text" id="no_ktp" class="form-control" name="no_ktp" />
					</div>
					<div class="form-group">
						<label>Tempat Lahir</label>
						<input type="text" class="form-control" id="tempat_lahir" name="tempat_lahir" />
					</div>
					<div class="form-group">
						<label>Tanggal Lahir</label>
						<input type="date" class="form-control" id="tgl_lahir" name="tgl_lahir"/>
					</div>
					<div class="form-group">
						<label>Alamat Lengkap</label>
						<textarea class="form-control" id="alamat_lengkap" name="alamat_lengkap" rows="3"></textarea>
					</div>
					<div class="form-group">
						<label>Posisi/Status</label>
						<select class="form-control" id="posisi" name="posisi">
							<option value="">-- Pilih Posisi/Status --</option>
							<?php foreach ($dt_posisi as $key => $dtpos) {?>
							<option value="<?php echo $dtpos['id_posisi']; ?>"><?php echo $dtpos['nama_posisi']; ?></option>
							<?php } ?>
						</select>
					</div>
					<div class="form-group">
						<label>Nama Ibu Kandung</label>
						<input type="text" class="form-control" id="nama_ibu" name="nama_ibu" />
					</div>
					<div class="form-group">
						<label>No Hp Alternatif</label>
						<input type="text" class="form-control" id="no_hp_alternatif" name="no_hp_alternatif" />
					</div>
					<div class="form-group">
						<label>No Hp Ooredoo</label>
						<input type="text" class="form-control" id="no_hp" name="no_hp" />
					</div>
					<div class="form-group">
						<label>Nama Bank</label>
						<input type="text" class="form-control" id="nama_bank" name="nama_bank" />
					</div>	
					<div class="form-group">
						<label>No Rek</label>
						<input type="text" class="form-control" id="no_rek" name="no_rek" />
					</div>	
					<hr style="border-color:#0000; border: 1px solid;"/>
					<div class="form-group">
						<label>Nama Pengiriman</label>
						<input type="text" class="form-control" id="nama_pengiriman" name="nama_pengiriman" />
					</div>	
					<div class="form-group">
						<label>Alamat Pengiriman</label>
						<textarea class="form-control" id="alamat_tujuan" name="alamat_tujuan" rows="3"></textarea>
					</div>
					<div class="form-group">
						<label>Kode POS</label>
						<input type="text" class="form-control" id="kode_pos" name="kode_pos" />
					</div>	
					<div class="form-group">
						<label>No Hp yang dapat dihubungi</label>
						<input type="text" class="form-control" id="no_hp_aktif" name="no_hp_aktif" />
					</div>		
			</div>
			<div class="box-footer">
				<button type="submit" id="formbtn" class="btn btn-success"><i class="fa fa-save"></i> Simpan</button>
				<a href="<?php echo base_url('admin/member'); ?>" class="btn btn-warning">Cancel</a>
			</div>
				</form>
		</div>
	</div>
</div>
<script type="text/javascript">
	$(document).ready(function(){
		$('#sponsor').blur(function(){
			var sponsor = $(this).val();
			if (sponsor == "") {
				$('#showresult').hide(500);
				$('#showresult').html("");
			}
			else{
				$.ajax({
					url: "<?php echo base_url('cek/sponsordaftar'); ?>/"+sponsor
				}).done(function(data){
					$('#showresult').html(data);
					$('#showresult').show(500);
				});
			}
		});
	});
</script>
<script>
	function validateText(id){
		if ($('#'+id).val()== null || $('#'+id).val()== "") {
			var div = $('#'+id).closest('div');
			div.addClass("has-error has-feedback");
			return false;
		}
		else{
			var div = $('#'+id).closest('div');
			div.removeClass("has-error has-feedback");
			return true;	
		}
	}
	$(document).ready(function(){
		$("#formbtn").click(function(){
			
			if (!validateText('sponsor')) {
				$('#sponsor').focus();
				return false;
			}
			else if (!validateText('nama')) {
				$('#nama').focus();
				return false;
			}
			else if (!validateText('no_ktp')) {
				$('#no_ktp').focus();
				return false;
			}
			else if (!validateText('tempat_lahir')) {
				$('#tempat_lahir').focus();
				return false;
			}
			else if (!validateText('tgl_lahir')) {
				$('#tgl_lahir').focus();
				return false;
			}
			else if (!validateText('alamat_lengkap')) {
				$('#alamat_lengkap').focus();
				return false;
			}
			else if (!validateText('posisi')) {
				$('#posisi').focus();
				return false;
			}
			else if (!validateText('nama_ibu')) {
				$('#nama_ibu').focus();
				return false;
			}
			else if (!validateText('no_hp_alternatif')) {
				$('#no_hp_alternatif').focus();
				return false;
			}
			else if (!validateText('no_hp')) {
				$('#no_hp').focus();
				return false;
			}
			else if (!validateText('nama_bank')) {
				$('#nama_bank').focus();
				return false;
			}
			else if (!validateText('no_rek')) {
				$('#no_rek').focus();
				return false;
			}
			else if (!validateText('nama_pengiriman')) {
				$('#nama_pengiriman').focus();
				return false;
			}
			else if (!validateText('alamat_tujuan')) {
				$('#alamat_tujuan').focus();
				return false;
			}
			else if (!validateText('kode_pos')) {
				$('#kode_pos').focus();
				return false;
			}
			else if (!validateText('no_hp_aktif')) {
				$('#no_hp_aktif').focus();
				return false;
			}
			return true;
		});
	});
</script>