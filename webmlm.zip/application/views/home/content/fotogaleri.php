<div class="container con-1">
	<div class="row">
		<div class="title">
          <h2 class="title-h2"><strong>Foto Galeri</strong></h2>
          <hr class="styletitle" />
        </div>
	</div>
	<div class="row">
	<?php foreach ($dt as $key => $data) { ?>
	  <div class="col-xs-6 col-md-3">
	  	<a href="<?php echo base_url('assets/foto-galeri'); ?>/<?php echo $data['foto']; ?>" class="thumbnail" data-lightbox="gallery" data-title="<?php echo $data['judul_foto']; ?>">
            <img src="<?php echo base_url('assets/foto-galeri'); ?>/<?php echo $data['foto']; ?>"alt="<?php echo $data['judul_foto']; ?>" width="180" style="width: 350px; height:200px;">
        </a>
	  </div>
	  <?php } ?>
	</div>
</div>