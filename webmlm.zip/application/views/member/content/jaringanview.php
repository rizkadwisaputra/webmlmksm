<div class="row">
	<div class="col-md-12 col-sm-12">
		<div class="box">
			<div class="box-header">
				<h2 class="box-title">Data Jaringan</h2>
			</div>
			<div class="box-body">
				<div class="table-responsive">
					<table class="table table-hover">
					<thead>
						<tr>
							<th>No</th>
							<th>Nama</th>
							<th>Alamat</th>
							<th>No Hp Ooredoo</th>
							<th>Merekrut</th>
							<th>Aksi</th>
						</tr>
					</thead>
					<tbody>
					<?php  foreach ($dt_jar as $key => $data) { ?>
						<tr>
							<td><?php echo $key+1; ?></td>
							<td><?php echo $data['nama_lengkap']; ?></td>
							<td><?php echo $data['alamat']; ?></td>
							<td><?php echo $data['no_hp_oredo']; ?></td>
							<td><?php echo $this->mod_member->CekJaringan($data['kd_sponsor']); ?></td>
							<td>
								<a href="<?php echo base_url('member/detailjaringan'); ?>/<?php echo $data['id_member']; ?>" class="btn btn-success" ><i class="fa fa-search"></i> Detail</a>
								
							</td>
						</tr>
					<?php } ?>
					</tbody>
				</table>
				</div>
			</div>
		</div>
	</div>
</div>