<div class="row">
	<div class="col-md-12">
		<div class="box">
			<div class="box-header">
				<h2 class="box-title">Detail Member</h2>
			</div>
			<div class="box-body">
				<h4>Data Login</h4>
				<table class="table">
					<tr>
						<td width="10%">Username</td>
						<td width="1%">:</td>
						<td><?php echo $dt['username']; ?></td>
					</tr>
					<tr>
						<td width="10%">Password</td>
						<td width="1%">:</td>
						<td><?php echo $dt['password']; ?></td>
					</tr>
				</table>
				<hr />
				<h4>Data Member</h4>
				<table class="table">
					<tr>
						<td width="10%">Nama</td>
						<td width="1%">:</td>
						<td><?php echo $dt['nama_lengkap']; ?></td>
					</tr>
					<tr>
						<td width="10%">Nomor ID</td>
						<td width="1%">:</td>
						<td><?php echo $dt['kd_sponsor']; ?></td>
					</tr>
					<tr>
						<td width="10%">No KTP</td>
						<td width="1%">:</td>
						<td><?php echo $dt['no_ktp']; ?></td>
					</tr>
					<tr>
						<td width="10%">Tempat Lahir</td>
						<td width="1%">:</td>
						<td><?php echo $dt['tempat_lahir']; ?></td>
					</tr>
					<tr>
						<td width="10%">Tanggal Lahir</td>
						<td width="1%">:</td>
						<td><?php echo date('d-m-Y', strtotime($dt['tgl_lahir'])); ?></td>
					</tr>
					<tr>
						<td width="10%">Alamat</td>
						<td width="1%">:</td>
						<td><?php echo $dt['alamat']; ?></td>
					</tr>
					<tr>
						<td width="10%">Posisi/Status</td>
						<td width="1%">:</td>
						<td><?php echo $dt['nama_posisi']; ?></td>
					</tr>
					<tr>
						<td width="10%">Nama Bank</td>
						<td width="1%">:</td>
						<td><?php echo $dt['nama_bank']; ?></td>
					</tr>
					<tr>
						<td width="10%">No REK</td>
						<td width="1%">:</td>
						<td><?php echo $dt['no_rek']; ?></td>
					</tr>
					<?php if ($dt_sponsor !== ""): ?>
					<tr>
						<td width="10%">Sponsor</td>
						<td width="1%">:</td>
						<td><?php echo $dt_sponsor['nama_lengkap']; ?></td>
					</tr>
					<?php endif ?>
					<tr>
						<td width="10%">Nama Ibu</td>
						<td width="1%">:</td>
						<td><?php echo $dt['nama_ibu_kandung']; ?></td>
					</tr>
					<tr>
						<td width="10%">No Hp Alternatif</td>
						<td width="1%">:</td>
						<td><?php echo $dt['no_hp_alternatif']; ?></td>
					</tr>
					<tr>
						<td width="10%">No Hp Ooredoo</td>
						<td width="1%">:</td>
						<td><?php echo $dt['no_hp_oredo']; ?></td>
					</tr>
					<tr>
						<td width="10%">Tgl Daftar</td>
						<td width="1%">:</td>
						<td><?php echo date('d F Y', strtotime($dt['tgl_masuk'])); ?></td>
					</tr>
				</table>
				<hr/>
				<h4>Data Pengiriman</h4>
				<br/>
				<table class="table">
					<tr>
						<td width="10%">Nama Pengiriman</td>
						<td width="1%">:</td>
						<td><?php echo $dt['nama_tujuan']; ?></td>
					</tr>
					<tr>
						<td width="10%">Alamat Tujuan</td>
						<td width="1%">:</td>
						<td><?php echo $dt['alamat_tujuan']; ?></td>
					</tr>
					<tr>
						<td width="10%">Kode POS</td>
						<td width="1%">:</td>
						<td><?php echo $dt['kode_pos']; ?></td>
					</tr>
					<tr>
						<td width="10%">No Hp Aktif</td>
						<td width="1%">:</td>
						<td><?php echo $dt['no_hp']; ?></td>
					</tr>
				</table>
			</div> 	
		</div>
	</div>
</div>